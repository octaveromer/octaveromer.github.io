pip install mysql-connector-python
pip install XlsxWriter

mot de passe user : bieber
mot de passe admin : ibazizou