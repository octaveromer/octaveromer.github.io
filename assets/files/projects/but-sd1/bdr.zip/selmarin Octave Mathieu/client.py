import os
import pandas as pd
import mysql.connector
from mysql.connector import Error

# Paramètres MySQL
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "selmarin"
}

# Fonction de connexion à MySQL
def connect_to_mysql():
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            print("Connexion réussie à MySQL")
            return connection
    except Error as e:
        print(f"Erreur de connexion à MySQL: {e}")
        return None

# Fonction pour importer client.csv
def import_client_csv(file_path):
    connection = connect_to_mysql()
    if not connection:
        return

    cursor = connection.cursor()

    if os.path.exists(file_path):
        print(f"Traitement du fichier : {file_path} pour la table client")

        df = pd.read_csv(file_path, sep=';', encoding='latin1')

        for _, row in df.iterrows():
            columns = ", ".join(df.columns)
            placeholders = ", ".join(["%s"] * len(df.columns))
            update_columns = ", ".join([f"{col}=VALUES({col})" for col in df.columns])
            sql = f"INSERT INTO client ({columns}) VALUES ({placeholders}) ON DUPLICATE KEY UPDATE {update_columns}"

            try:
                cursor.execute(sql, tuple(row))
                connection.commit()
            except Error as e:
                print(f"Erreur lors de l'insertion dans client: {e}")
                connection.rollback()

        print(f"Données insérées dans client depuis {file_path}")
    else:
        print(f"Fichier {file_path} non trouvé.")

    cursor.close()
    connection.close()
    print("Importation terminée !")

# Point d'entrée du script
if __name__ == "__main__":
    CSV_FOLDER = os.path.join(os.path.dirname(__file__), 'selmarinCSV')
    import_client_csv(os.path.join(CSV_FOLDER, 'client.csv'))
