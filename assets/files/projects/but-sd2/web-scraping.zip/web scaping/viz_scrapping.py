#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Visualisation Cartographique - Universités de France
BUT SD 2 - Saé VCOD - Collecte de données Web
Création d'une carte interactive et d'un graphique à partir des données scrapées
"""

import pandas as pd
import folium
import webbrowser
import matplotlib.pyplot as plt
import seaborn as sns
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter
import time

print("=== Visualisation des Universités de France ===\n")

# Chargement des données scrapées
print("Chargement des données depuis le fichier CSV...")
try:
    df = pd.read_csv('universites_france.csv', encoding='utf-8')
    print(f"Données chargées : {len(df)} universités")
    print(f"Colonnes disponibles : {list(df.columns)}\n")
except FileNotFoundError:
    print("ERREUR : Le fichier 'universites_france.csv' n'a pas été trouvé.")
    print("Veuillez d'abord exécuter scrapping.py")
    exit(1)

# Géolocalisation des villes
print("Géolocalisation des universités en cours...")
print("(Cette étape peut prendre quelques minutes)\n")

# Initialisation du géocodeur
geolocator = Nominatim(user_agent="universites_france_scraper")
# Ajout d'un délai entre les requêtes pour respecter les limites d'utilisation
geocode = RateLimiter(geolocator.geocode, min_delay_seconds=1)

latitudes = []
longitudes = []

for index, row in df.iterrows():
    try:
        ville = row['Ville']
        nom_univ = row['Nom']
        
        # Si la ville n'est pas renseignée, on essaie avec le nom de l'université
        if ville == "Non renseignée" or not ville:
            # Extraction du nom de la ville depuis le nom de l'université
            if ' de ' in nom_univ:
                ville_extrait = nom_univ.split(' de ')[-1].split(' ')[0]
                location = geocode(f"{ville_extrait}, France")
            else:
                location = None
        else:
            # Géolocalisation avec le nom de la ville
            location = geocode(f"{ville}, France")
        
        if location:
            latitudes.append(location.latitude)
            longitudes.append(location.longitude)
            print(f"✓ {nom_univ} - {ville} : ({location.latitude:.4f}, {location.longitude:.4f})")
        else:
            # Coordonnées par défaut (centre de la France) si non trouvé
            latitudes.append(46.603354)
            longitudes.append(1.888334)
            print(f"✗ {nom_univ} - {ville} : Coordonnées non trouvées (centre France par défaut)")
        
        # Pause pour respecter les limites de l'API
        time.sleep(0.5)
        
    except Exception as e:
        # En cas d'erreur, coordonnées par défaut
        latitudes.append(46.603354)
        longitudes.append(1.888334)
        print(f"✗ Erreur pour {row['Nom']} : {str(e)}")

# Ajout des coordonnées au DataFrame
df['Latitude'] = latitudes
df['Longitude'] = longitudes

print(f"\nGéolocalisation terminée : {len(df)} universités")

# ============================================
# CREATION DE LA CARTE FOLIUM INTERACTIVE
# ============================================
print("\n=== Création de la carte interactive ===")

# tiles permet de choisir le fond de carte
# On centre la carte sur la France
carte = folium.Map(
    location=[46.603354, 1.888334],  # Centre de la France
    zoom_start=6,
    tiles='OpenStreetMap'
)

# Ajout des marqueurs pour chaque université
for index, row in df.iterrows():
    # Création du contenu de la popup
    popup_html = f"""
    <div style="width: 250px;">
        <h4 style="color: #2c3e50; margin-bottom: 10px;">{row['Nom']}</h4>
        <hr style="margin: 5px 0;">
        <p style="margin: 5px 0;"><b>Ville :</b> {row['Ville']}</p>
        <p style="margin: 5px 0;"><b>Région :</b> {row['Région']}</p>
        <p style="margin: 5px 0;"><b>Effectif :</b> {row['Effectif']}</p>
        <p style="margin: 5px 0;">
            <a href="{row['URL']}" target="_blank" style="color: #3498db;">
                Page Wikipedia
            </a>
        </p>
    </div>
    """
    
    # Détermination de la couleur du marqueur selon la région
    # Création de couleurs différentes pour varier la visualisation
    couleurs = ['blue', 'red', 'green', 'purple', 'orange', 'darkred', 
                'lightred', 'beige', 'darkblue', 'darkgreen', 'cadetblue',
                'darkpurple', 'pink', 'lightblue', 'lightgreen', 'gray']
    
    # Attribution d'une couleur basée sur l'index (pour varier)
    couleur = couleurs[index % len(couleurs)]
    
    # Ajout du marqueur à la carte
    folium.Marker(
        location=[row['Latitude'], row['Longitude']],
        popup=folium.Popup(popup_html, max_width=300),
        tooltip=row['Nom'],
        icon=folium.Icon(color=couleur, icon='graduation-cap', prefix='fa')
    ).add_to(carte)

# Sauvegarde de la carte
nom_carte = 'carte_universites_france.html'
carte.save(nom_carte)
print(f"Carte sauvegardée : {nom_carte}")

# Ouverture automatique de la carte dans le navigateur
webbrowser.open_new_tab(nom_carte)
print("Carte ouverte dans le navigateur")

# ============================================
# CREATION D'UN GRAPHIQUE STATISTIQUE
# ============================================
print("\n=== Création du graphique statistique ===")

# Configuration du style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (14, 8)

# Création d'une figure avec 2 sous-graphiques
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# Graphique 1 : Nombre d'universités par région (top 10)
regions_count = df['Région'].value_counts()
# Exclusion des "Non renseignée"
regions_count = regions_count[regions_count.index != 'Non renseignée']
top_regions = regions_count.head(10)

ax1.barh(range(len(top_regions)), top_regions.values, color='steelblue')
ax1.set_yticks(range(len(top_regions)))
ax1.set_yticklabels(top_regions.index, fontsize=10)
ax1.set_xlabel('Nombre d\'universités', fontsize=12, fontweight='bold')
ax1.set_title('Top 10 des régions avec le plus d\'universités', 
              fontsize=14, fontweight='bold', pad=20)
ax1.invert_yaxis()

# Ajout des valeurs sur les barres
for i, v in enumerate(top_regions.values):
    ax1.text(v + 0.1, i, str(v), va='center', fontweight='bold')

# Graphique 2 : Répartition géographique (nuage de points)
# Exclusion des coordonnées par défaut pour une meilleure visualisation
df_geo = df[(df['Latitude'] != 46.603354) | (df['Longitude'] != 1.888334)]

scatter = ax2.scatter(df_geo['Longitude'], df_geo['Latitude'], 
                     c=range(len(df_geo)), cmap='viridis', 
                     s=100, alpha=0.6, edgecolors='black', linewidth=0.5)
ax2.set_xlabel('Longitude', fontsize=12, fontweight='bold')
ax2.set_ylabel('Latitude', fontsize=12, fontweight='bold')
ax2.set_title('Répartition géographique des universités françaises', 
              fontsize=14, fontweight='bold', pad=20)
ax2.grid(True, alpha=0.3)

# Ajout d'une colorbar
cbar = plt.colorbar(scatter, ax=ax2)
cbar.set_label('Index université', rotation=270, labelpad=20)

# Ajustement de la mise en page
plt.tight_layout()

# Sauvegarde du graphique
nom_graphique = 'graphique_universites_france.png'
plt.savefig(nom_graphique, dpi=300, bbox_inches='tight')
print(f"Graphique sauvegardé : {nom_graphique}")

# Affichage du graphique
plt.show()

# ============================================
# STATISTIQUES FINALES
# ============================================
print("\n=== Statistiques finales ===")
print(f"Nombre total d'universités : {len(df)}")
print(f"Nombre de régions représentées : {df['Région'].nunique()}")
print(f"Nombre de villes représentées : {df['Ville'].nunique()}")

print("\n=== Visualisation terminée avec succès ! ===")