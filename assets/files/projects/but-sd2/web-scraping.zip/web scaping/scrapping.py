#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Web Scraping - Universités de France
BUT SD 2 - Saé VCOD - Collecte de données Web
Scraping de la page Wikipedia des universités françaises
"""

import bs4
import urllib.request
import pandas as pd
import re

# URL de la page Wikipedia sur les universités en France
url = "https://fr.wikipedia.org/wiki/Liste_des_universit%C3%A9s_en_France"

print("Connexion à la page Wikipedia...")
# Etape 1 : se connecter à la page et obtenir le code source
page = urllib.request.urlopen(url).read()
# lxml permet d'utiliser un analyseur (parseur) HTML et XML
html = bs4.BeautifulSoup(page, "lxml")
print("Connexion réussie !")

# Initialisation des listes pour stocker les données
noms_universites = []
villes = []
regions = []
urls_universites = []
effectifs = []

print("\nRecherche des tableaux contenant les universités...")

# Etape 2 : Extraire les données des tableaux
# Les universités sont dans des tableaux avec la classe 'wikitable'
tables = html.find_all('table', {'class': 'wikitable'})

print(f"Nombre de tableaux trouvés : {len(tables)}")

# Parcourir les tableaux pertinents
for table in tables:
    # Recherche des lignes du tableau (balise tr)
    lignes = table.find_all('tr')
    
    for ligne in lignes[1:]:  # On saute la première ligne (en-têtes)
        cellules = ligne.find_all('td')
        
        # Vérification qu'on a bien des cellules dans la ligne
        if len(cellules) >= 2:
            try:
                # Récupération du nom de l'université (première cellule généralement)
                premiere_cellule = cellules[0]
                
                # Recherche du lien vers la page de l'université
                lien = premiere_cellule.find('a')
                if lien and lien.get('href'):
                    nom = lien.text.strip()
                    # Ne garder que les universités (exclure les autres établissements)
                    if 'université' in nom.lower() or 'Université' in nom:
                        url_univ = lien.get('href')
                        
                        # Reconstitution de l'URL complète
                        if url_univ.startswith('/wiki/'):
                            url_complete = "https://fr.wikipedia.org" + url_univ
                        else:
                            url_complete = url_univ
                        
                        # Récupération de la ville (généralement 2ème ou 3ème cellule)
                        ville = ""
                        region = ""
                        effectif = ""
                        
                        # Parcourir les cellules pour extraire les informations
                        for i, cellule in enumerate(cellules[1:], 1):
                            texte = cellule.text.strip()
                            
                            # La ville est souvent dans la 2ème cellule
                            if i == 1 and texte:
                                ville = texte
                            
                            # La région peut être dans une cellule suivante
                            if i == 2 and texte:
                                region = texte
                            
                            # L'effectif (si présent, souvent des chiffres)
                            if re.search(r'\d{3,}', texte):
                                effectif = texte
                        
                        # Ajout aux listes
                        noms_universites.append(nom)
                        villes.append(ville if ville else "Non renseignée")
                        regions.append(region if region else "Non renseignée")
                        urls_universites.append(url_complete)
                        effectifs.append(effectif if effectif else "Non renseigné")
                        
                        print(f"Université trouvée : {nom} - {ville}")
            
            except Exception as e:
                # En cas d'erreur sur une ligne, on continue
                continue

print(f"\nNombre d'universités récupérées : {len(noms_universites)}")

# Etape 3 : Création du DataFrame pandas
df_universites = pd.DataFrame({
    'Nom': noms_universites,
    'Ville': villes,
    'Région': regions,
    'URL': urls_universites,
    'Effectif': effectifs
})

print("\nAperçu des données récupérées :")
print(df_universites.head(10))
print(f"\nDimensions du DataFrame : {df_universites.shape}")

# Sauvegarde dans un fichier CSV
nom_fichier = 'universites_france.csv'
df_universites.to_csv(nom_fichier, index=False, encoding='utf-8')
print(f"\nDonnées sauvegardées dans '{nom_fichier}'")

print("\n=== Scraping terminé avec succès ! ===")