import requests
import json
import time

print("="*50)
print("TELECHARGEMENT DES DONNEES METEO")
print("="*50)

# URL API V2.1
URL = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/donnees-synop-essentielles-omm/records"

data_final = []
offset = 0
limit = 100
target = 1500  # On veut 1500 lignes pour avoir de beaux graphiques

print(f"[INFO] Objectif : récupérer {target} lignes...")

while len(data_final) < target:
    params = {
        'limit': limit,
        'offset': offset,
        'order_by': 'date DESC',
        'select': 'nom, date, tc, rr24, u, ff, pres, nom_reg, coordonnees'
    }
    
    try:
        r = requests.get(URL, params=params)
        if r.status_code == 200:
            results = r.json().get('results', [])
            if not results:
                break
                
            # Nettoyage immédiat
            for d in results:
                if d.get('coordonnees') and d.get('tc') is not None:
                    clean_d = {
                        'nom': d.get('nom', 'Inconnu'),
                        'lat': d['coordonnees']['lat'],
                        'lon': d['coordonnees']['lon'],
                        'tc': d.get('tc'),
                        'rr24': d.get('rr24', 0),
                        'u': d.get('u', 0),
                        'pres': d.get('pres'),
                        'ff': d.get('ff', 0),
                        'region': d.get('nom_reg', 'Autre'),
                        'date': d.get('date')
                    }
                    data_final.append(clean_d)
            
            print(f" -> Récupéré {len(data_final)} lignes...", end='\r')
            offset += limit
            time.sleep(0.2) # Petite pause pour être gentil avec l'API
        else:
            print(f"[ERREUR] API {r.status_code}")
            break
    except Exception as e:
        print(f"[CRASH] {e}")
        break

print(f"\n[OK] Total : {len(data_final)} lignes valides.")

# Astuce : On écrit un fichier .js avec une variable dedans pour éviter les blocages navigateur
with open("donnees.js", "w", encoding="utf-8") as f:
    json_content = json.dumps(data_final, ensure_ascii=False)
    f.write(f"const METEO_DATA = {json_content};")

print("[SUCCES] Fichier 'donnees.js' créé ! Tu peux ouvrir index.html.")