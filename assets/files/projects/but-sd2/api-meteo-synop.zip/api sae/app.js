// --- CONFIGURATION ---
// Dataset public Opendatasoft
const API_URL = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/donnees-synop-essentielles-omm/records";
const POITIERS = { lat: 46.5802, lon: 0.3404 }; // point central IUT

// --- VARIABLES GLOBALES ---
let DATA_FRANCE = [];
let DATA_POITIERS = [];

// --- OUTILS COMMUNS ---
async function fetchJson(url) {
    const res = await fetch(url);
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`HTTP ${res.status} pour ${url} :: ${text.slice(0, 160)}`);
    }
    return res.json();
}

function distanceKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
    return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// --- INITIALISATION ---
window.addEventListener("load", async () => {
    try {
        await Promise.all([fetchFranceData(), fetchPoitiersData()]);
        ensurePoitiersData(); // si la requete 100km renvoie 400, on filtre cote client

        initDashboard();
        document.getElementById("loading").style.opacity = "0";
        setTimeout(() => (document.getElementById("loading").style.display = "none"), 500);
    } catch (error) {
        console.error("Erreur critique:", error);
        alert(`Erreur de chargement API : ${error}. Verifiez votre connexion et les erreurs dans la console (F12).`);
    }
});

// --- 1. REQUETE GENERALE (FRANCE) ---
async function fetchFranceData() {
    const target = 800; // nombre souhaité
    const pageSize = 100; // max autorisé par l'API
    let offset = 0;
    let results = [];

    while (results.length < target) {
        const params = [
            `limit=${pageSize}`,
            `offset=${offset}`,
            "order_by=date%20DESC",
            "select=nom,date,tc,rr24,u,pres,ff,n,nom_reg,coordonnees"
        ].join("&");
        const url = `${API_URL}?${params}`;
        const json = await fetchJson(url);
        const batch = json.results || [];
        if (batch.length === 0) break;
        results = results.concat(batch);
        offset += pageSize;
    }

    DATA_FRANCE = results;
}

// --- 2. REQUETE SPECIFIQUE (POITIERS) ---
async function fetchPoitiersData() {
    // distance en metres, longitude d'abord puis latitude
    const geoFilter = `distance(coordonnees, geom'POINT(${POITIERS.lon} ${POITIERS.lat})', 100000)`;
    const pageSize = 100; // max API
    let offset = 0;
    let results = [];

    try {
        while (results.length < 200) {
            const params = [
                `limit=${pageSize}`,
                `offset=${offset}`,
                "order_by=date%20DESC",
                "select=nom,date,tc,rr24,u,pres,ff,n,nom_reg,coordonnees",
                `where=${encodeURIComponent(geoFilter)}`
            ].join("&");
            const url = `${API_URL}?${params}`;
            const json = await fetchJson(url);
            const batch = json.results || [];
            if (batch.length === 0) break;
            results = results.concat(batch);
            offset += pageSize;
        }
        DATA_POITIERS = results;
    } catch (err) {
        console.warn("Requete Poitiers 100km en erreur, fallback client :", err);
        DATA_POITIERS = [];
    }
}

// Fallback si l'API geo renvoie 400 : on filtre sur le jeu France
function ensurePoitiersData() {
    if (DATA_POITIERS.length === 0 && DATA_FRANCE.length > 0) {
        DATA_POITIERS = DATA_FRANCE
            .filter(d => d.coordonnees)
            .map(d => {
                const dist = distanceKm(POITIERS.lat, POITIERS.lon, d.coordonnees.lat, d.coordonnees.lon);
                return { ...d, __dist: dist };
            })
            .filter(d => d.__dist <= 100)
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 200);
    }
}

// --- DASHBOARD MASTER FUNCTION ---
function initDashboard() {
    updateKPI();
    renderMapA(); // A. Carte Moyenne
    renderChartB(); // B. Graphique Regions
    renderPoitiersC(); // C. Poitiers
    renderChartD(); // D. Libre
}

// --- KPI ---
function updateKPI() {
    if (DATA_FRANCE.length === 0) return;

    const temps = DATA_FRANCE.map(d => d.tc).filter(t => t !== null && t !== undefined);
    const avgTemp = temps.reduce((a, b) => a + b, 0) / (temps.length || 1);

    const hums = DATA_FRANCE.map(d => d.u).filter(x => x !== null && x !== undefined);
    const avgHum = hums.reduce((a, b) => a + b, 0) / (hums.length || 1);

    const press = DATA_FRANCE.map(d => d.pres).filter(x => x !== null && x !== undefined);
    const avgPress = press.reduce((a, b) => a + b, 0) / (press.length || 1);

    const totalPluie = DATA_FRANCE.map(d => d.rr24 || 0).reduce((a, b) => a + b, 0);

    document.getElementById("kpi-temp").innerText = `${avgTemp.toFixed(1)}°C`;
    document.getElementById("kpi-hum").innerText = `${avgHum.toFixed(0)}%`;
    document.getElementById("kpi-pluie").innerText = `${totalPluie.toFixed(0)}mm`;
    document.getElementById("kpi-press").innerText = `${(avgPress / 100).toFixed(0)} hPa`;
}

// --- A. CARTE INTERACTIVE (Moyenne par commune + Couleurs Classes) ---
function renderMapA() {
    const map = L.map("map").setView([46.5, 2.5], 6);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png").addTo(map);

    const stations = {};
    DATA_FRANCE.forEach(d => {
        if (!d.coordonnees || d.tc === null || d.tc === undefined) return;
        const nom = d.nom;
        if (!stations[nom]) stations[nom] = { lat: d.coordonnees.lat, lon: d.coordonnees.lon, sum: 0, count: 0 };
        stations[nom].sum += d.tc;
        stations[nom].count++;
    });

    for (const [nom, data] of Object.entries(stations)) {
        const moy = data.sum / data.count;
        let color = "#e74c3c"; // Rouge (>30)
        if (moy < 10) color = "#3498db"; // Bleu
        else if (moy < 20) color = "#2ecc71"; // Vert
        else if (moy < 30) color = "#f39c12"; // Orange

        L.circleMarker([data.lat, data.lon], {
            radius: 8,
            fillColor: color,
            color: "white",
            weight: 2,
            fillOpacity: 0.8
        })
            .addTo(map)
            .bindPopup(`<b>${nom}</b><br>Moyenne: ${moy.toFixed(1)}°C`)
            .bindTooltip(`${nom}: ${moy.toFixed(1)}°C`);
    }

    document.addEventListener("click", function () {
        map.invalidateSize();
    });
}

// --- B. GRAPHIQUE COMPARATIF (Region : Pluie vs Vent) ---
function renderChartB() {
    const regions = {};
    DATA_FRANCE.forEach(d => {
        const reg = d.nom_reg || "Autre";
        if (!regions[reg]) regions[reg] = { pluie_sum: 0, vent_sum: 0, count: 0 };
        regions[reg].pluie_sum += d.rr24 || 0;
        regions[reg].vent_sum += (d.ff || 0) * 3.6; // km/h
        regions[reg].count++;
    });

    const labels = Object.keys(regions)
        .sort()
        .filter(r => regions[r].count > 5);
    const dataPluie = labels.map(r => regions[r].pluie_sum / regions[r].count);
    const dataVent = labels.map(r => regions[r].vent_sum / regions[r].count);

    new Chart(document.getElementById("chart-region"), {
        type: "bar",
        data: {
            labels: labels,
            datasets: [
                { label: "Pluie moyenne sur 24h (mm)", data: dataPluie, backgroundColor: "#1abc9c" },
                { label: "Vent moyen (km/h)", data: dataVent, backgroundColor: "#f39c12" }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { title: { display: true, text: "Pluie et Vent par Region" } }
        }
    });
}

// --- C. POITIERS (< 100km) ---
function renderPoitiersC() {
    const mapP = L.map("map-poitiers").setView([POITIERS.lat, POITIERS.lon], 8);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png").addTo(mapP);

    L.marker([POITIERS.lat, POITIERS.lon]).addTo(mapP).bindPopup("<b>IUT Poitiers</b><br>Point Central").openPopup();
    L.circle([POITIERS.lat, POITIERS.lon], { radius: 100000, color: "#333", fill: false, dashArray: "5, 5" }).addTo(mapP);

    const tbody = document.querySelector("#table-poitiers tbody");

    DATA_POITIERS.forEach(d => {
        if (!d.coordonnees) return;
        const dist = d.__dist ?? distanceKm(POITIERS.lat, POITIERS.lon, d.coordonnees.lat, d.coordonnees.lon);

        L.circleMarker([d.coordonnees.lat, d.coordonnees.lon], {
            radius: 6,
            fillColor: "#9b59b6",
            color: "white",
            fillOpacity: 0.9
        }).addTo(mapP).bindPopup(`<b>${d.nom}</b><br>Temp: ${d.tc}°C`);

        if (tbody.children.length < 15) {
            const row = `<tr><td>${d.nom}</td><td>${d.tc}°C</td><td>${dist.toFixed(0)} km</td></tr>`;
            tbody.innerHTML += row;
        }
    });

    document.querySelectorAll('button[data-bs-target="#pills-c"]').forEach(btn => {
        btn.addEventListener("shown.bs.tab", () => mapP.invalidateSize());
    });
}

// --- D. INDICATEUR LIBRE (Scatter Plot: Temperature vs Humidite, taille = pluie) ---
function renderChartD() {
    const points = DATA_FRANCE.filter(d => d.tc !== null && d.u !== null).map(d => ({
        x: d.tc, // Temp en °C
        y: d.u, // Humidite %
        r: Math.max(4, Math.min(12, (d.rr24 || 0) + 4)),
        vent: (d.ff || 0) * 3.6
    }));

    new Chart(document.getElementById("chart-libre"), {
        type: "scatter",
        data: {
            datasets: [
                {
                    label: "Temp vs Humidite (taille = pluie, couleur = vent)",
                    data: points,
                    backgroundColor: ctx => {
                        const v = ctx.raw?.vent || 0;
                        const r = Math.min(255, 80 + v * 3);
                        return `rgba(${r}, 99, 132, 0.6)`;
                    },
                    pointRadius: ctx => ctx.raw?.r || 5
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { title: { display: true, text: "Température (°C)" } },
                y: { title: { display: true, text: "Humidité (%)" } }
            }
        }
    });
}
