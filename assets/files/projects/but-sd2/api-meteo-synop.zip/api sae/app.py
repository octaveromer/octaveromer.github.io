import requests
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import folium
import os
import webbrowser

# --- CONFIGURATION ---
API_URL = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/donnees-synop-essentielles-omm/records"
POITIERS = {"lat": 46.5802, "lon": 0.3404}

# Nettoyage des anciens fichiers
for f in ["index.html", "indicateur_b.png", "indicateur_d.png", "carte_a.html", "carte_c.html"]:
    if os.path.exists(f): os.remove(f)

print("="*50)
print("⛈️  LANCEMENT DE L'ANALYSE MÉTÉO")
print("="*50)

# =============================================================================
# 1. TÉLÉCHARGEMENT DES DONNÉES (Optimisé)
# =============================================================================
def get_data(limit=1000, geo_filter=None):
    print(f"[CHARGEMENT] Récupération de {limit} lignes API...")
    data = []
    offset = 0
    
    while len(data) < limit:
        params = {
            "limit": 100, "offset": offset, "order_by": "date DESC",
            "select": "nom,date,tc,rr24,u,pres,ff,nom_reg,coordonnees"
        }
        if geo_filter: params["where"] = geo_filter
        
        try:
            r = requests.get(API_URL, params=params)
            batch = r.json().get('results', [])
            if not batch: break
            data.extend(batch)
            offset += 100
            print(f" -> {len(data)} / {limit}...", end="\r")
        except: break
        
    df = pd.DataFrame(data)
    
    # Nettoyage
    cols = ['tc', 'rr24', 'u', 'pres', 'ff']
    for c in cols: 
        if c in df.columns: df[c] = pd.to_numeric(df[c], errors='coerce')
    
    if 'coordonnees' in df.columns:
        df['lat'] = df['coordonnees'].apply(lambda x: x['lat'] if x else None)
        df['lon'] = df['coordonnees'].apply(lambda x: x['lon'] if x else None)
        
    return df.dropna(subset=['lat', 'lon', 'tc'])

# --- Chargement ---
# 1. Données France
df_france = get_data(limit=800)
# 2. Données Poitiers (Force la zone)
geo_poitiers = f"distance(coordonnees, geom'POINT({POITIERS['lon']} {POITIERS['lat']})', 100km)"
df_poitiers = get_data(limit=100, geo_filter=geo_poitiers)

print("\n[OK] Données récupérées.")

# =============================================================================
# 2. CRÉATION DES INDICATEURS (VISUELS)
# =============================================================================

# --- A. CARTE INTERACTIVE FRANCE (Fichier HTML) ---
print("[1/4] Génération Carte France...")
map_a = folium.Map(location=[46.5, 2.5], zoom_start=6)
for _, row in df_france.groupby('nom').mean(numeric_only=True).reset_index().iterrows():
    color = 'blue' if row['tc'] < 10 else 'green' if row['tc'] < 20 else 'orange' if row['tc'] < 30 else 'red'
    folium.CircleMarker(
        [row['lat'], row['lon']], radius=7, color=color, fill=True, fillOpacity=0.7,
        popup=f"{row['nom']}: {row['tc']:.1f}°C"
    ).add_to(map_a)
map_a.save("carte_a.html")

# --- B. GRAPHIQUE REGIONS (Image PNG) ---
print("[2/4] Génération Graphique Régions...")
plt.figure(figsize=(10, 5))
sns.set_theme(style="whitegrid")
df_reg = df_france.groupby('nom_reg')[['tc', 'rr24']].mean().reset_index()
sns.barplot(data=df_reg, x='nom_reg', y='tc', palette='viridis')
plt.title("Température Moyenne par Région")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("indicateur_b.png")
plt.close()

# --- C. CARTE POITIERS (Fichier HTML) ---
print("[3/4] Génération Carte Poitiers...")
map_c = folium.Map(location=[POITIERS['lat'], POITIERS['lon']], zoom_start=8)
folium.Marker([POITIERS['lat'], POITIERS['lon']], popup="IUT", icon=folium.Icon(color='black')).add_to(map_c)
folium.Circle([POITIERS['lat'], POITIERS['lon']], radius=100000, color='black', fill=False).add_to(map_c)

for _, row in df_poitiers.iterrows():
    folium.CircleMarker(
        [row['lat'], row['lon']], radius=6, color='purple', fill=True,
        popup=f"{row['nom']}: {row['tc']}°C"
    ).add_to(map_c)
map_c.save("carte_c.html")

# --- D. INDICATEUR LIBRE (Image PNG) ---
print("[4/4] Génération Indicateur Libre...")
plt.figure(figsize=(10, 5))
sns.scatterplot(data=df_france, x='pres', y='u', size='rr24', hue='ff', palette='coolwarm')
plt.title("Pression vs Humidité (Taille=Pluie, Couleur=Vent)")
plt.tight_layout()
plt.savefig("indicateur_d.png")
plt.close()

# =============================================================================
# 3. GÉNÉRATION DU SITE WEB (INDEX.HTML)
# =============================================================================
print("[FINAL] Création du site web...")

html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Météo Auto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {{ background: #f4f4f4; padding: 20px; }}
        .card {{ margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
        iframe {{ width: 100%; height: 400px; border: none; }}
        img {{ width: 100%; height: auto; }}
        h1 {{ color: #2c3e50; margin-bottom: 30px; text-align: center; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🌩️ Dashboard Météo Généré par Python</h1>
        
        <div class="card p-3">
            <h3>🌍 A. Carte des Températures</h3>
            <iframe src="carte_a.html"></iframe>
        </div>

        <div class="card p-3">
            <h3>📊 B. Comparatif Régions</h3>
            <img src="indicateur_b.png">
        </div>

        <div class="card p-3">
            <h3>🎯 C. Focus Poitiers (<100km)</h3>
            <iframe src="carte_c.html"></iframe>
        </div>

        <div class="card p-3">
            <h3>⚡ D. Indicateur Libre</h3>
            <img src="indicateur_d.png">
        </div>
    </div>
</body>
</html>
"""

with open("index.html", "w", encoding="utf-8") as f:
    f.write(html_content)

print("✅ TERMINÉ ! Ouverture du navigateur...")
webbrowser.open("index.html")