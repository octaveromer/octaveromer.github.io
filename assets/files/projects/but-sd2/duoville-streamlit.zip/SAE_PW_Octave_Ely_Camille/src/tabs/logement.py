"""
Onglet Logement : répartition, occupation, taux comparatifs.
"""

import streamlit
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from src.config import COULEUR_A, COULEUR_B
from src.utils import fmt, delta_str
from src.charts import style_figure, afficher_graphique


def afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B):
    streamlit.header("Indicateurs Logement", divider="blue")

    log_total_A, rp_A, rs_A = temp_A['P22_LOG'].values[0], temp_A['P22_RP'].values[0], temp_A['P22_RSECOCC'].values[0]
    vac_A, prop_A = temp_A['P22_LOGVAC'].values[0], temp_A['P22_RP_PROP'].values[0]
    log_total_B, rp_B, rs_B = temp_B['P22_LOG'].values[0], temp_B['P22_RP'].values[0], temp_B['P22_RSECOCC'].values[0]
    vac_B, prop_B = temp_B['P22_LOGVAC'].values[0], temp_B['P22_RP_PROP'].values[0]

    taux_vac_A = (vac_A / log_total_A * 100) if log_total_A > 0 else 0
    taux_vac_B = (vac_B / log_total_B * 100) if log_total_B > 0 else 0
    taux_prop_A = (prop_A / rp_A * 100) if rp_A > 0 else 0
    taux_prop_B = (prop_B / rp_B * 100) if rp_B > 0 else 0

    col1, col2 = streamlit.columns(2)
    with col1:
        streamlit.subheader(f"🔵 {ville_A}")
        m1, m2, m3 = streamlit.columns(3)
        m1.metric("Logements totaux", fmt(log_total_A), delta=delta_str(log_total_A, log_total_B))
        m2.metric("Taux de vacance", f"{taux_vac_A:.1f}%", delta=delta_str(taux_vac_A, taux_vac_B, "%"), delta_color="inverse")
        m3.metric("Taux propriétaires", f"{taux_prop_A:.1f}%", delta=delta_str(taux_prop_A, taux_prop_B, "%"))
    with col2:
        streamlit.subheader(f"🟠 {ville_B}")
        m1, m2, m3 = streamlit.columns(3)
        m1.metric("Logements totaux", fmt(log_total_B), delta=delta_str(log_total_B, log_total_A))
        m2.metric("Taux de vacance", f"{taux_vac_B:.1f}%", delta=delta_str(taux_vac_B, taux_vac_A, "%"), delta_color="inverse")
        m3.metric("Taux propriétaires", f"{taux_prop_B:.1f}%", delta=delta_str(taux_prop_B, taux_prop_A, "%"))

    streamlit.divider()
    streamlit.subheader("📊 Détails des logements")

    fig_log = make_subplots(rows=1, cols=3,
        subplot_titles=("Répartition", "Statut d'occupation", "Taux comparatifs"))

    fig_log.add_trace(go.Bar(name=ville_A, x=['Rés. principales', 'Rés. secondaires', 'Vacants'],
        y=[rp_A, rs_A, vac_A], marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A'), row=1, col=1)
    fig_log.add_trace(go.Bar(name=ville_B, x=['Rés. principales', 'Rés. secondaires', 'Vacants'],
        y=[rp_B, rs_B, vac_B], marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B'), row=1, col=1)

    fig_log.add_trace(go.Bar(name=ville_A, x=['Propriétaires', 'Locataires'],
        y=[prop_A, rp_A - prop_A], marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A', showlegend=False), row=1, col=2)
    fig_log.add_trace(go.Bar(name=ville_B, x=['Propriétaires', 'Locataires'],
        y=[prop_B, rp_B - prop_B], marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B', showlegend=False), row=1, col=2)

    fig_log.add_trace(go.Bar(name=ville_A, x=['Taux vacance', 'Taux propriétaires'],
        y=[taux_vac_A, taux_prop_A], text=[f"{taux_vac_A:.1f}%", f"{taux_prop_A:.1f}%"], textposition='auto',
        marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A', showlegend=False), row=1, col=3)
    fig_log.add_trace(go.Bar(name=ville_B, x=['Taux vacance', 'Taux propriétaires'],
        y=[taux_vac_B, taux_prop_B], text=[f"{taux_vac_B:.1f}%", f"{taux_prop_B:.1f}%"], textposition='auto',
        marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B', showlegend=False), row=1, col=3)

    style_figure(fig_log)
    afficher_graphique(fig_log, "chart_logement")
