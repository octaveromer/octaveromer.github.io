"""
Onglet Formation : données Parcoursup.
"""

import streamlit
import pandas
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from src.config import COULEUR_A, COULEUR_B
from src.utils import fmt, delta_str
from src.charts import style_figure, afficher_graphique


def _filtrer_formations_ville(formations_data, col_commune, ville):
    """Filtre les formations d'une ville avec fallback arrondissements pour grandes communes."""
    commune_norm = formations_data[col_commune].astype(str).str.strip().str.lower()
    ville_norm = ville.strip().lower()

    exact = formations_data[commune_norm == ville_norm]
    if not exact.empty:
        return exact

    if ville_norm in {'paris', 'marseille', 'lyon'}:
        masque_arr = commune_norm.str.match(fr'^{ville_norm}\s+\d+', na=False)
        return formations_data[masque_arr]

    return exact


def afficher(ville_A, ville_B, opacity_A, opacity_B, formations_data):
    streamlit.header("Indicateurs Formation (Parcoursup)", divider="blue")

    col_commune = 'Commune de l\u2019établissement'
    if col_commune not in formations_data.columns:
        col_commune = "Commune de l'établissement"

    if col_commune not in formations_data.columns:
        streamlit.error("Colonne des communes introuvable dans le fichier Parcoursup.")
        return

    formations_A = _filtrer_formations_ville(formations_data, col_commune, ville_A)
    formations_B = _filtrer_formations_ville(formations_data, col_commune, ville_B)

    col_filiere = 'Filière de formation très agrégée'
    col_capacite = 'Capacité de l\u2019établissement par formation'
    if col_capacite not in formations_data.columns:
        col_capacite = "Capacité de l'établissement par formation"
    col_selectivite = 'Sélectivité'
    col_statut = 'Statut de l\u2019établissement de la filière de formation (public, privé…)'
    if col_statut not in formations_data.columns:
        col_statut = "Statut de l'établissement de la filière de formation (public, privé…)"

    filieres_dispos = list(set(
        formations_A[col_filiere].dropna().unique().tolist() +
        formations_B[col_filiere].dropna().unique().tolist()
    ))

    if not filieres_dispos:
        streamlit.warning("Aucune donnée de formation pour ces villes.")
        return

    st_filiere_filter = streamlit.multiselect("Filtrer par filière :", filieres_dispos, default=filieres_dispos)

    form_A_f = formations_A[formations_A[col_filiere].isin(st_filiere_filter)]
    form_B_f = formations_B[formations_B[col_filiere].isin(st_filiere_filter)]
    nb_A, nb_B = len(form_A_f), len(form_B_f)
    capa_A = pandas.to_numeric(form_A_f[col_capacite], errors='coerce').sum()
    capa_B = pandas.to_numeric(form_B_f[col_capacite], errors='coerce').sum()

    col1, col2 = streamlit.columns(2)
    with col1:
        streamlit.subheader(f"🔵 {ville_A}")
        m1, m2 = streamlit.columns(2)
        m1.metric("Formations", nb_A, delta=delta_str(nb_A, nb_B))
        m2.metric("Places totales", fmt(capa_A), delta=delta_str(capa_A, capa_B))
    with col2:
        streamlit.subheader(f"🟠 {ville_B}")
        m1, m2 = streamlit.columns(2)
        m1.metric("Formations", nb_B, delta=delta_str(nb_B, nb_A))
        m2.metric("Places totales", fmt(capa_B), delta=delta_str(capa_B, capa_A))

    streamlit.divider()

    fig_formation = make_subplots(rows=1, cols=3,
        subplot_titles=("Par filière", "Sélectivité", "Statut (Public/Privé)"))

    comptage_A = form_A_f[col_filiere].value_counts().reindex(st_filiere_filter, fill_value=0)
    comptage_B = form_B_f[col_filiere].value_counts().reindex(st_filiere_filter, fill_value=0)
    fig_formation.add_trace(go.Bar(name=ville_A, x=st_filiere_filter, y=comptage_A,
        marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A'), row=1, col=1)
    fig_formation.add_trace(go.Bar(name=ville_B, x=st_filiere_filter, y=comptage_B,
        marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B'), row=1, col=1)

    sel_A = form_A_f[col_selectivite].astype(str).value_counts()
    sel_B = form_B_f[col_selectivite].astype(str).value_counts()
    tous_sel = list(set([str(x) for x in sel_A.index.tolist() + sel_B.index.tolist()]))
    fig_formation.add_trace(go.Bar(name=ville_A, x=tous_sel, y=sel_A.reindex(tous_sel, fill_value=0),
        marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A', showlegend=False), row=1, col=2)
    fig_formation.add_trace(go.Bar(name=ville_B, x=tous_sel, y=sel_B.reindex(tous_sel, fill_value=0),
        marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B', showlegend=False), row=1, col=2)

    statut_A = form_A_f[col_statut].astype(str).value_counts()
    statut_B = form_B_f[col_statut].astype(str).value_counts()
    tous_statut = list(set([str(x) for x in statut_A.index.tolist() + statut_B.index.tolist()]))
    labels_courts = [s.replace("Privé sous contrat d'association", "Privé (Contrat)")
                      .replace("Privé hors contrat", "Privé (HC)")
                      .replace("Privé enseignement supérieur", "Privé (Sup)") for s in tous_statut]
    fig_formation.add_trace(go.Bar(name=ville_A, x=labels_courts, y=statut_A.reindex(tous_statut, fill_value=0),
        marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A', showlegend=False), row=1, col=3)
    fig_formation.add_trace(go.Bar(name=ville_B, x=labels_courts, y=statut_B.reindex(tous_statut, fill_value=0),
        marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B', showlegend=False), row=1, col=3)

    style_figure(fig_formation, 500)
    afficher_graphique(fig_formation, "chart_formation")
