"""
Onglet Sports : équipements sportifs via data.sports.gouv.fr.
"""

import streamlit
import pandas
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from src.config import COULEUR_A, COULEUR_B
from src.utils import fmt, delta_str, exploser_liste
from src.api import obtenir_equipements_sportifs
from src.charts import style_figure, afficher_graphique


def afficher(ville_A, ville_B, opacity_A, opacity_B):
    streamlit.header("Indicateurs Sports", divider="blue")
    streamlit.info("🏟️ Données : Recensement des Équipements Sportifs (data.sports.gouv.fr)")

    with streamlit.spinner("Chargement des données sportives..."):
        sport_A = obtenir_equipements_sportifs(ville_A)
        sport_B = obtenir_equipements_sportifs(ville_B)

    col1, col2 = streamlit.columns(2)
    with col1:
        streamlit.subheader(f"🔵 {ville_A}")
        streamlit.metric("Équipements recensés", len(sport_A), delta=delta_str(len(sport_A), len(sport_B)))
    with col2:
        streamlit.subheader(f"🟠 {ville_B}")
        streamlit.metric("Équipements recensés", len(sport_B), delta=delta_str(len(sport_B), len(sport_A)))

    if not sport_A.empty or not sport_B.empty:
        streamlit.divider()
        streamlit.subheader("📊 Comparaison des équipements sportifs")

        count_A = sport_A['equip_type_name'].dropna().astype(str).value_counts().head(10) if not sport_A.empty and 'equip_type_name' in sport_A.columns else pandas.Series(dtype=int)
        count_B = sport_B['equip_type_name'].dropna().astype(str).value_counts().head(10) if not sport_B.empty and 'equip_type_name' in sport_B.columns else pandas.Series(dtype=int)
        all_types = list(dict.fromkeys(count_A.index.tolist() + count_B.index.tolist()))[:12]

        act_A = exploser_liste(sport_A, 'gen_2024fin_labellisation').head(10)
        act_B = exploser_liste(sport_B, 'gen_2024fin_labellisation').head(10)
        all_acts = list(dict.fromkeys(act_A.index.tolist() + act_B.index.tolist()))[:12]

        has_types = len(all_types) > 0
        has_acts = len(all_acts) > 0
        nb_cols = (1 if has_types else 0) + (1 if has_acts else 0)

        if nb_cols > 0:
            titles = []
            if has_types:
                titles.append("Types d'équipements")
            if has_acts:
                titles.append("Activités praticables")
            fig_sport = make_subplots(rows=1, cols=nb_cols, subplot_titles=titles)

            col_idx = 1
            if has_types:
                fig_sport.add_trace(go.Bar(name=ville_A, x=all_types,
                    y=[count_A.get(t, 0) for t in all_types],
                    marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A'), row=1, col=col_idx)
                fig_sport.add_trace(go.Bar(name=ville_B, x=all_types,
                    y=[count_B.get(t, 0) for t in all_types],
                    marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B'), row=1, col=col_idx)
                col_idx += 1

            if has_acts:
                fig_sport.add_trace(go.Bar(name=ville_A, x=all_acts,
                    y=[act_A.get(a, 0) for a in all_acts],
                    marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A', showlegend=not has_types), row=1, col=col_idx)
                fig_sport.add_trace(go.Bar(name=ville_B, x=all_acts,
                    y=[act_B.get(a, 0) for a in all_acts],
                    marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B', showlegend=not has_types), row=1, col=col_idx)

            style_figure(fig_sport, 500)
            afficher_graphique(fig_sport, "chart_sport")

        # Intérieur vs Extérieur
        if 'equip_nature' in (sport_A.columns.tolist() if not sport_A.empty else []) + (sport_B.columns.tolist() if not sport_B.empty else []):
            streamlit.divider()
            streamlit.subheader("🏠 Intérieur vs Extérieur")
            nature_A = sport_A['equip_nature'].dropna().astype(str).value_counts() if not sport_A.empty and 'equip_nature' in sport_A.columns else pandas.Series(dtype=int)
            nature_B = sport_B['equip_nature'].dropna().astype(str).value_counts() if not sport_B.empty and 'equip_nature' in sport_B.columns else pandas.Series(dtype=int)
            poubelle_nature = {'nan', 'None', '', 'NaN', 'null'}
            nature_A = nature_A[~nature_A.index.isin(poubelle_nature)]
            nature_B = nature_B[~nature_B.index.isin(poubelle_nature)]
            all_natures = list(dict.fromkeys(nature_A.index.tolist() + nature_B.index.tolist()))
            if all_natures:
                fig_nature = go.Figure()
                fig_nature.add_trace(go.Bar(name=ville_A, x=all_natures,
                    y=[nature_A.get(n, 0) for n in all_natures],
                    marker_color=COULEUR_A, opacity=opacity_A))
                fig_nature.add_trace(go.Bar(name=ville_B, x=all_natures,
                    y=[nature_B.get(n, 0) for n in all_natures],
                    marker_color=COULEUR_B, opacity=opacity_B))
                style_figure(fig_nature, 350)
                afficher_graphique(fig_nature, "chart_sport_nature")

        # Propriétaire des équipements
        if 'equip_prop_type' in (sport_A.columns.tolist() if not sport_A.empty else []) + (sport_B.columns.tolist() if not sport_B.empty else []):
            streamlit.divider()
            streamlit.subheader("🏛️ Propriétaire des équipements")
            prop_A = sport_A['equip_prop_type'].dropna().astype(str).value_counts() if not sport_A.empty and 'equip_prop_type' in sport_A.columns else pandas.Series(dtype=int)
            prop_B = sport_B['equip_prop_type'].dropna().astype(str).value_counts() if not sport_B.empty and 'equip_prop_type' in sport_B.columns else pandas.Series(dtype=int)
            prop_A = prop_A[~prop_A.index.isin({'nan', 'None', '', 'NaN', 'null'})]
            prop_B = prop_B[~prop_B.index.isin({'nan', 'None', '', 'NaN', 'null'})]
            all_props = list(dict.fromkeys(prop_A.index.tolist() + prop_B.index.tolist()))
            if all_props:
                fig_prop = go.Figure()
                fig_prop.add_trace(go.Bar(name=ville_A, x=all_props,
                    y=[prop_A.get(p, 0) for p in all_props],
                    marker_color=COULEUR_A, opacity=opacity_A))
                fig_prop.add_trace(go.Bar(name=ville_B, x=all_props,
                    y=[prop_B.get(p, 0) for p in all_props],
                    marker_color=COULEUR_B, opacity=opacity_B))
                style_figure(fig_prop, 350)
                afficher_graphique(fig_prop, "chart_sport_prop")
    else:
        streamlit.warning("Aucune donnée sportive trouvée pour ces villes via l'API.")
