"""
Onglet Météo : prévisions 5 jours via Open-Meteo.
"""

import streamlit
import plotly.graph_objects as go
from src.config import COULEUR_A, COULEUR_B
from src.api import obtenir_meteo
from src.utils import code_meteo_vers_emoji


def afficher(ville_A, ville_B, lat_A, lon_A, lat_B, lon_B):
    streamlit.header("Conditions Météorologiques", divider="blue")
    streamlit.info("🌍 Données en temps réel via Open-Meteo API (prévisions 5 jours)")

    col1, col2 = streamlit.columns(2)

    for col_widget, ville, lat, lon, couleur in [
        (col1, ville_A, lat_A, lon_A, COULEUR_A),
        (col2, ville_B, lat_B, lon_B, COULEUR_B)
    ]:
        with col_widget:
            emoji_ville = "🔵" if ville == ville_A else "🟠"
            streamlit.subheader(f"{emoji_ville} {ville}")
            meteo = obtenir_meteo(ville, lat, lon)

            if meteo and 'daily' in meteo:
                daily = meteo['daily']
                for i in range(min(5, len(daily['time']))):
                    d = daily['time'][i]
                    tmax, tmin = daily['temperature_2m_max'][i], daily['temperature_2m_min'][i]
                    precip = daily['precipitation_sum'][i]
                    emoji = code_meteo_vers_emoji(daily['weathercode'][i])
                    with streamlit.expander(f"{emoji} {d} — {tmin:.0f}°C / {tmax:.0f}°C", expanded=(i == 0)):
                        c1, c2, c3 = streamlit.columns(3)
                        c1.metric("🌡️ Max", f"{tmax:.1f}°C")
                        c2.metric("🌡️ Min", f"{tmin:.1f}°C")
                        c3.metric("🌧️ Précip.", f"{precip:.1f} mm")

                fig_temp = go.Figure()
                fig_temp.add_trace(go.Scatter(x=daily['time'][:5], y=daily['temperature_2m_max'][:5],
                    mode='lines+markers', name='Max', line=dict(color='#ef4444', width=2), marker=dict(size=8)))
                fig_temp.add_trace(go.Scatter(x=daily['time'][:5], y=daily['temperature_2m_min'][:5],
                    mode='lines+markers', name='Min', line=dict(color='#3b82f6', width=2), marker=dict(size=8)))
                fig_temp.update_layout(title=f"Températures — {ville}", xaxis_title="Date",
                    yaxis_title="°C", height=300, plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)')
                streamlit.plotly_chart(fig_temp, use_container_width=True)
            else:
                streamlit.error("❌ Données météo indisponibles")

    streamlit.divider()
    streamlit.caption("📡 Données fournies par Open-Meteo.com")
