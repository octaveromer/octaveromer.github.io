"""
Onglet Généralités : informations générales, radar, carte, export.
"""

import streamlit
import pandas
import plotly.express as px
import plotly.graph_objects as go
from src.config import COULEUR_A, COULEUR_B
from src.utils import fmt, delta_str, normaliser


def afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B, villes_data):
    streamlit.header("Informations Générales", divider="blue")

    pop_A, pop_B = int(temp_A['P22_POP'].values[0]), int(temp_B['P22_POP'].values[0])
    sup_A, sup_B = int(temp_A['SUPERF'].values[0]), int(temp_B['SUPERF'].values[0])
    densite_A = int(pop_A / sup_A) if sup_A > 0 else 0
    densite_B = int(pop_B / sup_B) if sup_B > 0 else 0
    men_A, men_B = int(temp_A['P22_MEN'].values[0]), int(temp_B['P22_MEN'].values[0])
    rev_A, rev_B = int(temp_A['MED21'].values[0]), int(temp_B['MED21'].values[0])

    col1, col2 = streamlit.columns(2)
    with col1:
        streamlit.subheader(f"🔵 {ville_A}")
        m1, m2, m3 = streamlit.columns(3)
        m1.metric("Population", fmt(pop_A), delta=delta_str(pop_A, pop_B))
        m2.metric("Superficie (km²)", fmt(sup_A))
        m3.metric("Densité (hab/km²)", fmt(densite_A), delta=delta_str(densite_A, densite_B))
        m4, m5 = streamlit.columns(2)
        m4.metric("Ménages", fmt(men_A), delta=delta_str(men_A, men_B))
        m5.metric("Revenu médian", f"{fmt(rev_A)} €", delta=delta_str(rev_A, rev_B, " €"))

    with col2:
        streamlit.subheader(f"🟠 {ville_B}")
        m1, m2, m3 = streamlit.columns(3)
        m1.metric("Population", fmt(pop_B), delta=delta_str(pop_B, pop_A))
        m2.metric("Superficie (km²)", fmt(sup_B))
        m3.metric("Densité (hab/km²)", fmt(densite_B), delta=delta_str(densite_B, densite_A))
        m4, m5 = streamlit.columns(2)
        m4.metric("Ménages", fmt(men_B), delta=delta_str(men_B, men_A))
        m5.metric("Revenu médian", f"{fmt(rev_B)} €", delta=delta_str(rev_B, rev_A, " €"))

    # ─── Radar chart synthèse ───
    streamlit.divider()
    streamlit.subheader("🕸️ Profil comparatif")

    indicateurs_radar = {
        'Population': ('P22_POP', False),
        'Revenu médian': ('MED21', False),
        'Taux activité': (None, False),
        'Emplois': ('P22_EMPLT', False),
        'Logements': ('P22_LOG', False),
        'Ménages': ('P22_MEN', False),
    }

    actifs_A_r = temp_A['P22_ACT1564'].values[0]
    pop1564_A_r = temp_A['P22_POP1564'].values[0]
    actifs_B_r = temp_B['P22_ACT1564'].values[0]
    pop1564_B_r = temp_B['P22_POP1564'].values[0]
    taux_act_A_r = (actifs_A_r / pop1564_A_r * 100) if pop1564_A_r > 0 else 0
    taux_act_B_r = (actifs_B_r / pop1564_B_r * 100) if pop1564_B_r > 0 else 0

    categories_radar = list(indicateurs_radar.keys())
    scores_A, scores_B = [], []
    for cat, (col, _) in indicateurs_radar.items():
        if cat == 'Taux activité':
            scores_A.append(max(0, min(100, (taux_act_A_r - 50) / 35 * 100)))
            scores_B.append(max(0, min(100, (taux_act_B_r - 50) / 35 * 100)))
        else:
            scores_A.append(normaliser(temp_A[col].values[0], col, villes_data))
            scores_B.append(normaliser(temp_B[col].values[0], col, villes_data))

    fig_radar = go.Figure()
    fig_radar.add_trace(go.Scatterpolar(
        r=scores_A + [scores_A[0]], theta=categories_radar + [categories_radar[0]],
        fill='toself', name=ville_A,
        line=dict(color=COULEUR_A, width=2),
        fillcolor=f'rgba(99, 102, 241, {0.25 * opacity_A})',
        opacity=opacity_A
    ))
    fig_radar.add_trace(go.Scatterpolar(
        r=scores_B + [scores_B[0]], theta=categories_radar + [categories_radar[0]],
        fill='toself', name=ville_B,
        line=dict(color=COULEUR_B, width=2),
        fillcolor=f'rgba(249, 115, 22, {0.25 * opacity_B})',
        opacity=opacity_B
    ))
    fig_radar.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 100], showticklabels=False)),
        height=420, margin=dict(t=40, b=40, l=60, r=60),
        plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)',
        font=dict(family='Inter, sans-serif'),
        legend=dict(orientation="h", yanchor="bottom", y=1.08, xanchor="center", x=0.5)
    )
    streamlit.plotly_chart(fig_radar, use_container_width=True)

    # ─── Carte ───
    streamlit.divider()
    streamlit.subheader("🗺️ Localisation géographique")

    villes_comparees = pandas.concat([temp_A, temp_B])
    villes_comparees['SUPERF'] = pandas.to_numeric(villes_comparees['SUPERF'], errors='coerce')
    villes_comparees['P22_POP'] = pandas.to_numeric(villes_comparees['P22_POP'], errors='coerce')
    villes_comparees['densite'] = (villes_comparees['P22_POP'] / villes_comparees['SUPERF']).fillna(0)
    villes_comparees['pop_fmt'] = villes_comparees['P22_POP'].apply(lambda x: fmt(int(x)) if pandas.notna(x) else "N/A")
    villes_comparees['superf_fmt'] = villes_comparees['SUPERF'].apply(lambda x: f"{x:.1f}" if pandas.notna(x) else "N/A")
    villes_comparees['densite_fmt'] = villes_comparees['densite'].apply(lambda x: fmt(int(x)) if pandas.notna(x) else "N/A")

    fig_carte = px.scatter_mapbox(
        villes_comparees, lat="latitude", lon="longitude",
        hover_name="nom_commune_complet",
        custom_data=['nom_departement', 'pop_fmt', 'superf_fmt', 'densite_fmt'],
        size="P22_POP", color="nom_commune_complet",
        color_discrete_map={ville_A: COULEUR_A, ville_B: COULEUR_B},
        zoom=5.5, height=500, mapbox_style="carto-positron"
    )
    fig_carte.update_traces(
        hovertemplate=(
            "<b>%{hovertext}</b><br>"
            "Département : %{customdata[0]}<br>"
            "Population : %{customdata[1]} hab<br>"
            "Superficie : %{customdata[2]} km²<br>"
            "Densité : %{customdata[3]} hab/km²"
            "<extra></extra>"
        ),
        hoverlabel=dict(
            bgcolor="rgba(255,255,255,0.96)",
            bordercolor="#6366f1",
            font=dict(color="#0f172a", size=13)
        )
    )
    fig_carte.update_layout(
        margin={"r": 0, "t": 0, "l": 0, "b": 0},
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    streamlit.plotly_chart(fig_carte, use_container_width=True)

    # ─── Export CSV ───
    streamlit.divider()
    streamlit.subheader("📥 Exporter les données")
    export_data = pandas.DataFrame({
        'Indicateur': ['Population', 'Superficie (km²)', 'Densité (hab/km²)', 'Ménages', 'Revenu médian (€)'],
        ville_A: [pop_A, sup_A, densite_A, men_A, rev_A],
        ville_B: [pop_B, sup_B, densite_B, men_B, rev_B],
        'Écart': [pop_A - pop_B, sup_A - sup_B, densite_A - densite_B, men_A - men_B, rev_A - rev_B],
    })
    streamlit.download_button(
        "📥 Télécharger le comparatif (CSV)",
        export_data.to_csv(index=False, sep=";").encode('utf-8'),
        file_name=f"comparatif_{ville_A}_{ville_B}.csv",
        mime="text/csv"
    )
