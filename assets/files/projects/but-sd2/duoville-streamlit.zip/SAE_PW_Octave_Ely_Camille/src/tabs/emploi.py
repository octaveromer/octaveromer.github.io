"""
Onglet Emploi : taux d'activité, chômage, secteurs, évolution.
"""

import streamlit
import pandas
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from src.config import COULEUR_A, COULEUR_B, SECTEURS_LABELS
from src.utils import fmt, delta_str
from src.charts import style_figure, afficher_graphique


def afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B):
    streamlit.header("Indicateurs Emploi", divider="blue")

    pop15_64_A, actifs_A, chomeurs_A = temp_A['P22_POP1564'].values[0], temp_A['P22_ACT1564'].values[0], temp_A['P22_CHOM1564'].values[0]
    emplois_A, emplois_sal_A = temp_A['P22_EMPLT'].values[0], temp_A['P22_EMPLT_SAL'].values[0]
    pop15_64_B, actifs_B, chomeurs_B = temp_B['P22_POP1564'].values[0], temp_B['P22_ACT1564'].values[0], temp_B['P22_CHOM1564'].values[0]
    emplois_B, emplois_sal_B = temp_B['P22_EMPLT'].values[0], temp_B['P22_EMPLT_SAL'].values[0]

    taux_chom_A = (chomeurs_A / actifs_A * 100) if actifs_A > 0 else 0
    taux_chom_B = (chomeurs_B / actifs_B * 100) if actifs_B > 0 else 0
    taux_act_A = (actifs_A / pop15_64_A * 100) if pop15_64_A > 0 else 0
    taux_act_B = (actifs_B / pop15_64_B * 100) if pop15_64_B > 0 else 0

    col1, col2 = streamlit.columns(2)
    with col1:
        streamlit.subheader(f"🔵 {ville_A}")
        m1, m2, m3 = streamlit.columns(3)
        m1.metric("Taux d'activité", f"{taux_act_A:.1f}%", delta=delta_str(taux_act_A, taux_act_B, "%"))
        m2.metric("Taux de chômage", f"{taux_chom_A:.1f}%", delta=delta_str(taux_chom_A, taux_chom_B, "%"), delta_color="inverse")
        m3.metric("Emplois totaux", fmt(emplois_A), delta=delta_str(emplois_A, emplois_B))
    with col2:
        streamlit.subheader(f"🟠 {ville_B}")
        m1, m2, m3 = streamlit.columns(3)
        m1.metric("Taux d'activité", f"{taux_act_B:.1f}%", delta=delta_str(taux_act_B, taux_act_A, "%"))
        m2.metric("Taux de chômage", f"{taux_chom_B:.1f}%", delta=delta_str(taux_chom_B, taux_chom_A, "%"), delta_color="inverse")
        m3.metric("Emplois totaux", fmt(emplois_B), delta=delta_str(emplois_B, emplois_A))

    streamlit.divider()
    streamlit.subheader("📊 Comparaison détaillée")
    streamlit.caption("💡 Cliquez sur une barre pour isoler cette ville sur tous les graphiques.")

    fig_emploi = make_subplots(rows=1, cols=3,
        subplot_titles=("Répartition 15-64 ans", "Taux d'activité / chômage", "Structure de l'emploi"))

    fig_emploi.add_trace(go.Bar(name=ville_A, x=['Actifs occupés', 'Chômeurs', 'Inactifs'],
        y=[actifs_A - chomeurs_A, chomeurs_A, pop15_64_A - actifs_A],
        marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A'), row=1, col=1)
    fig_emploi.add_trace(go.Bar(name=ville_B, x=['Actifs occupés', 'Chômeurs', 'Inactifs'],
        y=[actifs_B - chomeurs_B, chomeurs_B, pop15_64_B - actifs_B],
        marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B'), row=1, col=1)

    fig_emploi.add_trace(go.Bar(name=ville_A, x=["Taux d'activité", "Taux de chômage"],
        y=[taux_act_A, taux_chom_A], text=[f"{taux_act_A:.1f}%", f"{taux_chom_A:.1f}%"], textposition='auto',
        marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A', showlegend=False), row=1, col=2)
    fig_emploi.add_trace(go.Bar(name=ville_B, x=["Taux d'activité", "Taux de chômage"],
        y=[taux_act_B, taux_chom_B], text=[f"{taux_act_B:.1f}%", f"{taux_chom_B:.1f}%"], textposition='auto',
        marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B', showlegend=False), row=1, col=2)

    fig_emploi.add_trace(go.Bar(name=ville_A, x=['Salariés', 'Non-salariés'],
        y=[emplois_sal_A, emplois_A - emplois_sal_A],
        marker_color=COULEUR_A, opacity=opacity_A, legendgroup='A', showlegend=False), row=1, col=3)
    fig_emploi.add_trace(go.Bar(name=ville_B, x=['Salariés', 'Non-salariés'],
        y=[emplois_sal_B, emplois_B - emplois_sal_B],
        marker_color=COULEUR_B, opacity=opacity_B, legendgroup='B', showlegend=False), row=1, col=3)

    style_figure(fig_emploi)
    afficher_graphique(fig_emploi, "chart_emploi")

    # ─── Secteurs d'activité ───
    streamlit.divider()
    streamlit.subheader("🏭 Établissements par secteur d'activité")

    secteurs_cols = [c for c in SECTEURS_LABELS.keys() if c in temp_A.columns and c in temp_B.columns]
    if secteurs_cols:
        labels_sec = [SECTEURS_LABELS[c] for c in secteurs_cols]
        vals_sec_A = [pandas.to_numeric(temp_A[c].values[0], errors='coerce') or 0 for c in secteurs_cols]
        vals_sec_B = [pandas.to_numeric(temp_B[c].values[0], errors='coerce') or 0 for c in secteurs_cols]

        fig_secteur = go.Figure()
        fig_secteur.add_trace(go.Bar(name=ville_A, x=labels_sec, y=vals_sec_A,
            marker_color=COULEUR_A, opacity=opacity_A, text=[fmt(v) for v in vals_sec_A], textposition='auto'))
        fig_secteur.add_trace(go.Bar(name=ville_B, x=labels_sec, y=vals_sec_B,
            marker_color=COULEUR_B, opacity=opacity_B, text=[fmt(v) for v in vals_sec_B], textposition='auto'))
        style_figure(fig_secteur, 400)
        afficher_graphique(fig_secteur, "chart_secteur")

    # ─── Évolution temporelle ───
    pop_A = int(temp_A['P22_POP'].values[0])
    pop_B = int(temp_B['P22_POP'].values[0])
    pop16_A = pandas.to_numeric(temp_A['P16_POP'].values[0], errors='coerce')
    pop16_B = pandas.to_numeric(temp_B['P16_POP'].values[0], errors='coerce')
    emp16_A = pandas.to_numeric(temp_A['P16_EMPLT'].values[0], errors='coerce')
    emp16_B = pandas.to_numeric(temp_B['P16_EMPLT'].values[0], errors='coerce')

    if not pandas.isna(pop16_A) and not pandas.isna(pop16_B):
        streamlit.divider()
        streamlit.subheader("📈 Évolution 2016 → 2022")

        fig_evol = make_subplots(rows=1, cols=2,
            subplot_titles=("Population", "Emplois"))

        fig_evol.add_trace(go.Scatter(x=['2016', '2022'], y=[pop16_A, pop_A],
            mode='lines+markers+text', name=ville_A, text=[fmt(pop16_A), fmt(pop_A)], textposition='top center',
            line=dict(color=COULEUR_A, width=3), marker=dict(size=10), opacity=opacity_A), row=1, col=1)
        fig_evol.add_trace(go.Scatter(x=['2016', '2022'], y=[pop16_B, pop_B],
            mode='lines+markers+text', name=ville_B, text=[fmt(pop16_B), fmt(pop_B)], textposition='top center',
            line=dict(color=COULEUR_B, width=3), marker=dict(size=10), opacity=opacity_B), row=1, col=1)

        if not pandas.isna(emp16_A) and not pandas.isna(emp16_B):
            fig_evol.add_trace(go.Scatter(x=['2016', '2022'], y=[emp16_A, emplois_A],
                mode='lines+markers+text', name=ville_A, text=[fmt(emp16_A), fmt(emplois_A)], textposition='top center',
                line=dict(color=COULEUR_A, width=3), marker=dict(size=10), opacity=opacity_A, showlegend=False), row=1, col=2)
            fig_evol.add_trace(go.Scatter(x=['2016', '2022'], y=[emp16_B, emplois_B],
                mode='lines+markers+text', name=ville_B, text=[fmt(emp16_B), fmt(emplois_B)], textposition='top center',
                line=dict(color=COULEUR_B, width=3), marker=dict(size=10), opacity=opacity_B, showlegend=False), row=1, col=2)

        fig_evol.update_layout(
            height=380, plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)',
            font=dict(family='Inter, sans-serif'), margin=dict(t=40, b=40),
        )
        streamlit.plotly_chart(fig_evol, use_container_width=True)

        evol_pop_A = (pop_A - pop16_A) / pop16_A * 100 if pop16_A > 0 else 0
        evol_pop_B = (pop_B - pop16_B) / pop16_B * 100 if pop16_B > 0 else 0
        c1, c2 = streamlit.columns(2)
        c1.metric(f"Évolution population {ville_A}", f"{evol_pop_A:+.1f}%")
        c2.metric(f"Évolution population {ville_B}", f"{evol_pop_B:+.1f}%")
