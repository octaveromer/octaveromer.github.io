"""
Onglet Classement : rangs et percentiles parmi toutes les villes.
"""

import streamlit
import pandas
import plotly.graph_objects as go
from src.config import COULEUR_A, COULEUR_B
from src.utils import delta_str


def afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B, villes_data):
    streamlit.header("Classement parmi toutes les villes", divider="blue")
    nb_villes = len(villes_data)
    streamlit.info(f"📊 Position de {ville_A} et {ville_B} parmi les {nb_villes} villes de + de 20 000 habitants")

    indicateurs_classement = {
        'Population': ('P22_POP', False),
        'Revenu médian': ('MED21', False),
        'Emplois': ('P22_EMPLT', False),
        'Logements': ('P22_LOG', False),
        'Ménages': ('P22_MEN', False),
    }

    villes_data_calc = villes_data.copy()
    villes_data_calc['_taux_activite'] = (
        pandas.to_numeric(villes_data_calc['P22_ACT1564'], errors='coerce') /
        pandas.to_numeric(villes_data_calc['P22_POP1564'], errors='coerce') * 100
    )
    villes_data_calc['_taux_chomage'] = (
        pandas.to_numeric(villes_data_calc['P22_CHOM1564'], errors='coerce') /
        pandas.to_numeric(villes_data_calc['P22_ACT1564'], errors='coerce') * 100
    )
    villes_data_calc['_taux_vacance'] = (
        pandas.to_numeric(villes_data_calc['P22_LOGVAC'], errors='coerce') /
        pandas.to_numeric(villes_data_calc['P22_LOG'], errors='coerce') * 100
    )
    villes_data_calc['_densite'] = (
        pandas.to_numeric(villes_data_calc['P22_POP'], errors='coerce') /
        pandas.to_numeric(villes_data_calc['SUPERF'], errors='coerce')
    )

    indicateurs_classement["Taux d'activité"] = ('_taux_activite', False)
    indicateurs_classement['Taux de chômage'] = ('_taux_chomage', True)
    indicateurs_classement['Taux de vacance'] = ('_taux_vacance', True)
    indicateurs_classement['Densité'] = ('_densite', False)

    resultats = []
    for nom_indic, (col_name, inverse) in indicateurs_classement.items():
        col_data = pandas.to_numeric(villes_data_calc[col_name], errors='coerce')
        rang_series = col_data.rank(ascending=inverse, method='min')

        idx_A = temp_A.index[0]
        idx_B = temp_B.index[0]
        rang_A = int(rang_series.loc[idx_A]) if idx_A in rang_series.index and not pandas.isna(rang_series.loc[idx_A]) else nb_villes
        rang_B = int(rang_series.loc[idx_B]) if idx_B in rang_series.index and not pandas.isna(rang_series.loc[idx_B]) else nb_villes

        resultats.append({
            'Indicateur': nom_indic,
            f'Rang {ville_A}': f"{rang_A}/{nb_villes}",
            f'Top % {ville_A}': f"{rang_A/nb_villes*100:.0f}%",
            f'Rang {ville_B}': f"{rang_B}/{nb_villes}",
            f'Top % {ville_B}': f"{rang_B/nb_villes*100:.0f}%",
            'Meilleur': ville_A if rang_A < rang_B else (ville_B if rang_B < rang_A else 'Égalité'),
        })

    df_classement = pandas.DataFrame(resultats)
    streamlit.dataframe(df_classement, use_container_width=True, hide_index=True)

    # Graphique des rangs
    streamlit.divider()
    streamlit.subheader("📊 Positionnement comparé")

    indic_names = [r['Indicateur'] for r in resultats]
    rangs_A = [int(r[f'Rang {ville_A}'].split('/')[0]) for r in resultats]
    rangs_B = [int(r[f'Rang {ville_B}'].split('/')[0]) for r in resultats]
    pct_A = [round((1 - r / nb_villes) * 100) for r in rangs_A]
    pct_B = [round((1 - r / nb_villes) * 100) for r in rangs_B]

    fig_rank = go.Figure()
    fig_rank.add_trace(go.Bar(name=ville_A, x=indic_names, y=pct_A,
        marker_color=COULEUR_A, opacity=opacity_A,
        text=[f"Top {100-p}%" for p in pct_A], textposition='auto'))
    fig_rank.add_trace(go.Bar(name=ville_B, x=indic_names, y=pct_B,
        marker_color=COULEUR_B, opacity=opacity_B,
        text=[f"Top {100-p}%" for p in pct_B], textposition='auto'))
    fig_rank.update_layout(
        yaxis_title="Percentile (100 = meilleur)",
        barmode='group', height=450,
        plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)',
        font=dict(family='Inter, sans-serif'), margin=dict(t=40, b=40),
    )
    fig_rank.add_hline(y=50, line_dash="dash", line_color="gray", annotation_text="Médiane nationale")
    streamlit.plotly_chart(fig_rank, use_container_width=True)

    # Score global
    streamlit.divider()
    streamlit.subheader("🏅 Score global")
    score_A = round(sum(pct_A) / len(pct_A))
    score_B = round(sum(pct_B) / len(pct_B))
    c1, c2 = streamlit.columns(2)
    c1.metric(f"🔵 {ville_A}", f"{score_A}/100", delta=delta_str(score_A, score_B, " pts"))
    c2.metric(f"🟠 {ville_B}", f"{score_B}/100", delta=delta_str(score_B, score_A, " pts"))
