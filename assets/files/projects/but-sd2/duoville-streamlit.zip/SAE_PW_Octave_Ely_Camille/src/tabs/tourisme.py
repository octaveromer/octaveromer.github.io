"""
Onglet Tourisme : lieux touristiques via Overpass API.
"""

import streamlit
import pandas
import plotly.express as px
import plotly.graph_objects as go
from src.config import COULEUR_A, COULEUR_B, LABELS_TOURISME
from src.utils import delta_str
from src.api import obtenir_lieux_touristiques
from src.charts import style_figure, afficher_graphique


def afficher(ville_A, ville_B, lat_A, lon_A, lat_B, lon_B, opacity_A, opacity_B):
    streamlit.header("Indicateurs Tourisme", divider="blue")
    streamlit.info("🗺️ Données : OpenStreetMap via Overpass API (lieux touristiques dans un rayon de 10 km)")

    with streamlit.spinner("Chargement des données touristiques..."):
        tourisme_A = obtenir_lieux_touristiques(lat_A, lon_A)
        tourisme_B = obtenir_lieux_touristiques(lat_B, lon_B)

    col1, col2 = streamlit.columns(2)
    with col1:
        streamlit.subheader(f"🔵 {ville_A}")
        streamlit.metric("Sites touristiques", len(tourisme_A), delta=delta_str(len(tourisme_A), len(tourisme_B)))
    with col2:
        streamlit.subheader(f"🟠 {ville_B}")
        streamlit.metric("Sites touristiques", len(tourisme_B), delta=delta_str(len(tourisme_B), len(tourisme_A)))

    if not tourisme_A.empty or not tourisme_B.empty:
        streamlit.divider()
        streamlit.subheader("📊 Types de sites touristiques")

        types_A = tourisme_A['type'].map(lambda x: LABELS_TOURISME.get(x, x.title())).value_counts() if not tourisme_A.empty else pandas.Series(dtype=int)
        types_B = tourisme_B['type'].map(lambda x: LABELS_TOURISME.get(x, x.title())).value_counts() if not tourisme_B.empty else pandas.Series(dtype=int)
        all_types = list(dict.fromkeys([str(x) for x in types_A.index.tolist() + types_B.index.tolist()]))

        fig_tourisme = go.Figure()
        fig_tourisme.add_trace(go.Bar(name=ville_A, x=all_types,
            y=[types_A.get(t, 0) for t in all_types],
            marker_color=COULEUR_A, opacity=opacity_A))
        fig_tourisme.add_trace(go.Bar(name=ville_B, x=all_types,
            y=[types_B.get(t, 0) for t in all_types],
            marker_color=COULEUR_B, opacity=opacity_B))
        style_figure(fig_tourisme, 450)
        afficher_graphique(fig_tourisme, "chart_tourisme")

        # Carte des lieux touristiques
        streamlit.divider()
        streamlit.subheader("🗺️ Carte des sites touristiques")

        lieux_carte = []
        if not tourisme_A.empty:
            t_a = tourisme_A.copy()
            t_a['ville'] = ville_A
            lieux_carte.append(t_a)
        if not tourisme_B.empty:
            t_b = tourisme_B.copy()
            t_b['ville'] = ville_B
            lieux_carte.append(t_b)

        if lieux_carte:
            df_carte = pandas.concat(lieux_carte, ignore_index=True)
            df_carte['label'] = df_carte['type'].map(lambda x: LABELS_TOURISME.get(x, x.title()))

            fig_carte_t = px.scatter_mapbox(
                df_carte, lat='lat', lon='lon',
                hover_name='nom', hover_data={'lat': False, 'lon': False, 'label': True, 'ville': True},
                color='ville', color_discrete_map={ville_A: COULEUR_A, ville_B: COULEUR_B},
                zoom=6, height=500, mapbox_style='carto-positron'
            )
            fig_carte_t.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0},
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
            streamlit.plotly_chart(fig_carte_t, use_container_width=True)

        # Liste des lieux
        streamlit.divider()
        streamlit.subheader("📋 Liste des sites")
        col1, col2 = streamlit.columns(2)
        with col1:
            if not tourisme_A.empty:
                for _, row in tourisme_A.head(15).iterrows():
                    label = LABELS_TOURISME.get(row['type'], row['type'].title())
                    streamlit.write(f"🔵 **{row['nom']}** — {label}")
            else:
                streamlit.caption("Aucun site trouvé")
        with col2:
            if not tourisme_B.empty:
                for _, row in tourisme_B.head(15).iterrows():
                    label = LABELS_TOURISME.get(row['type'], row['type'].title())
                    streamlit.write(f"🟠 **{row['nom']}** — {label}")
            else:
                streamlit.caption("Aucun site trouvé")
    else:
        streamlit.warning("Aucune donnée touristique trouvée pour ces villes via l'API.")
