"""
Fonctions de mise en forme et d'affichage des graphiques Plotly.
"""

import streamlit


def style_figure(fig, hauteur=450):
    """Applique le style commun aux figures."""
    fig.update_layout(
        barmode='group', height=hauteur,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(family='Inter, sans-serif'),
        margin=dict(t=40, b=40),
        clickmode='event+select',
        transition_duration=400,
    )
    fig.update_traces(selected=dict(marker=dict(opacity=1.0)),
                      unselected=dict(marker=dict(opacity=1.0)))


def afficher_graphique(fig, chart_key):
    """Affiche un graphique plotly avec cross-filtering par clic sur barre."""
    event = streamlit.plotly_chart(fig, use_container_width=True, key=chart_key, on_select="rerun", selection_mode=["points"])
    try:
        points = event.selection.points if event and event.selection else []
    except Exception:
        points = []
    if points:
        pt = points[0]
        curve_num = pt.get('curve_number', pt.get('curveNumber', 0))
        # Récupérer les noms de ville depuis session_state
        ville_A = streamlit.session_state.get('ville_a')
        ville_B = streamlit.session_state.get('ville_b')
        clicked_ville = ville_A if curve_num % 2 == 0 else ville_B
        current = streamlit.session_state.get('mise_en_avant', 'Les deux')
        if current == clicked_ville:
            streamlit.session_state['_pending_mise_en_avant'] = 'Les deux'
        else:
            streamlit.session_state['_pending_mise_en_avant'] = clicked_ville
        streamlit.rerun()
