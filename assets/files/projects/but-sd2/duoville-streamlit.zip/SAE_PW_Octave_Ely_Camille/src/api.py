"""
Fonctions d'appel aux APIs externes.
"""

import streamlit
import pandas
import requests


@streamlit.cache_data(ttl=3600)
def obtenir_meteo(ville_nom, latitude, longitude):
    """Prévisions météo via Open-Meteo API."""
    try:
        r = requests.get("https://api.open-meteo.com/v1/forecast", params={
            "latitude": latitude, "longitude": longitude,
            "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode",
            "timezone": "Europe/Paris", "forecast_days": 5
        }, timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None


@streamlit.cache_data(ttl=3600, show_spinner=False)
def obtenir_equipements_sportifs(commune_nom):
    """Équipements sportifs via data.sports.gouv.fr."""
    try:
        commune = str(commune_nom).strip()
        commune_title = commune.title()
        commune_lower = commune.lower()

        where_clause = f'new_name="{commune_title}"'
        if commune_lower in {'paris', 'marseille', 'lyon'}:
            where_clause = f'(new_name="{commune_title}" OR new_name like "{commune_title} %")'

        tous_records = []
        offset = 0
        while True:
            r = requests.get(
                "https://data.sports.gouv.fr/api/explore/v2.1/catalog/datasets/equipements-sportifs/records",
                params={"where": where_clause, "limit": 100, "offset": offset},
                timeout=10
            )
            r.raise_for_status()
            data = r.json()
            records = data.get('results', [])
            if not records:
                break
            tous_records.extend(records)
            if len(tous_records) >= data.get('total_count', 0):
                break
            offset += 100
        if not tous_records:
            return pandas.DataFrame()
        df = pandas.DataFrame(tous_records)
        colonnes_utiles = ['inst_nom', 'equip_nom', 'equip_type_name', 'equip_nature',
                           'equip_prop_type', 'gen_2024fin_labellisation', 'equip_coordonnees']
        colonnes_presentes = [c for c in colonnes_utiles if c in df.columns]
        df = df[colonnes_presentes]
        if 'equip_type_name' in df.columns:
            df = df.dropna(subset=['equip_type_name'])
            df = df[df['equip_type_name'].astype(str).str.strip() != '']
        return df
    except Exception:
        return pandas.DataFrame()


@streamlit.cache_data(ttl=3600, show_spinner=False)
def obtenir_lieux_touristiques(lat, lon, rayon=10000):
    """Lieux touristiques via Overpass API (OpenStreetMap)."""
    types_exclus = {'yes', 'information', 'apartment', 'caravan_site', 'picnic_site'}
    try:
        query = f'[out:json][timeout:10];node["tourism"](around:{rayon},{lat},{lon});out body;'
        r = requests.post("https://overpass-api.de/api/interpreter", data={"data": query}, timeout=15)
        r.raise_for_status()
        elements = r.json().get('elements', [])
        lieux = []
        for el in elements:
            tags = el.get('tags', {})
            nom = tags.get('name', '').strip()
            type_lieu = tags.get('tourism', 'autre').strip()
            if nom and type_lieu not in types_exclus:
                lieux.append({
                    'nom': nom,
                    'type': type_lieu,
                    'lat': el.get('lat'),
                    'lon': el.get('lon')
                })
        return pandas.DataFrame(lieux) if lieux else pandas.DataFrame()
    except Exception:
        return pandas.DataFrame()
