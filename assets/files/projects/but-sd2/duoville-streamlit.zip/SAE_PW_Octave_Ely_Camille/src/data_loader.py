"""
Chargement et préparation des données CSV.
"""

import os
import streamlit
import pandas
from src.config import DATA_DIR


def _regrouper_arrondissements_municipaux(df):
    """Regroupe les arrondissements municipaux (Paris, Marseille, Lyon) en une seule ligne par ville."""
    if df.empty or 'nom_commune_complet' not in df.columns:
        return df

    df_result = df.copy()
    ville_configs = [
        {'ville': 'Paris', 'code': '75056'},
        {'ville': 'Marseille', 'code': '13055'},
        {'ville': 'Lyon', 'code': '69123'}
    ]

    for config in ville_configs:
        ville = config['ville']
        code_ville = config['code']
        mask = df_result['nom_commune_complet'].str.contains(fr'^{ville}\s+\d+', case=False, na=False)
        arrondissements = df_result[mask]

        if arrondissements.empty:
            continue

        df_result = df_result[~mask].copy()

        ville_groupee = arrondissements.iloc[0].copy()
        ville_groupee['nom_commune_complet'] = ville

        for code_col in ['CODGEO', 'code_commune_INSEE']:
            if code_col in ville_groupee.index:
                ville_groupee[code_col] = code_ville

        if 'latitude' in arrondissements.columns:
            ville_groupee['latitude'] = pandas.to_numeric(arrondissements['latitude'], errors='coerce').mean()
        if 'longitude' in arrondissements.columns:
            ville_groupee['longitude'] = pandas.to_numeric(arrondissements['longitude'], errors='coerce').mean()

        poids = pandas.to_numeric(arrondissements['P22_POP'], errors='coerce').fillna(0)
        poids_total = poids.sum()

        for col in arrondissements.columns:
            if col in ['nom_commune_complet', 'CODGEO', 'code_commune_INSEE', 'latitude', 'longitude']:
                continue

            serie_num = pandas.to_numeric(arrondissements[col], errors='coerce')
            if serie_num.notna().sum() == 0:
                continue

            if col in ['MED21', 'TP6021'] and poids_total > 0:
                ville_groupee[col] = (serie_num.fillna(0) * poids).sum() / poids_total
            else:
                ville_groupee[col] = serie_num.sum()

        df_result = pandas.concat([df_result, pandas.DataFrame([ville_groupee])], ignore_index=True)

    return df_result


@streamlit.cache_data
def charger_donnees():
    """Charge et fusionne données INSEE + GPS, filtre > 20 000 hab."""
    data_insee = pandas.read_csv(os.path.join(DATA_DIR, "base_cc_comparateur.csv"), sep=";", low_memory=False)
    data_gps = pandas.read_csv(os.path.join(DATA_DIR, "20230823-communes-departement-region.csv"), sep=",")
    data_gps["code_commune_INSEE"] = data_gps["code_commune_INSEE"].astype(str).str.zfill(5)
    data_insee["CODGEO"] = data_insee["CODGEO"].astype(str).str.zfill(5)
    data_20k = data_insee.query("P22_POP > 20000")
    result = pandas.merge(data_20k, data_gps, left_on="CODGEO", right_on="code_commune_INSEE", how="inner")
    result = result.drop_duplicates(subset=['CODGEO'])
    result = _regrouper_arrondissements_municipaux(result)
    return result.sort_values(by="nom_commune_complet")


@streamlit.cache_data
def charger_formations():
    """Charge les données Parcoursup."""
    return pandas.read_csv(os.path.join(DATA_DIR, "base_formation_parcoursup.csv"), sep=";", low_memory=False)
