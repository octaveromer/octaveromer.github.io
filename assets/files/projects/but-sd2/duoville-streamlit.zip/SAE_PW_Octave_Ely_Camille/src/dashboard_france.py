"""
Dashboard Vue d'ensemble France - Toutes les villes > 20 000 habitants
"""

import streamlit
import pandas
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from src.config import COULEUR_A, COULEUR_B
from src.utils import fmt


def afficher(villes_data):
    """Affiche le dashboard vue d'ensemble de la France."""

    # ═══════════════════════════════════════════════════════════════════════════════
    # PRÉPARATION DES DONNÉES
    # ═══════════════════════════════════════════════════════════════════════════════

    # Conversion des colonnes numériques
    numeric_cols = ['P22_POP', 'SUPERF', 'MED21', 'P22_EMPLT', 'P22_CHOM1564', 'P22_ACT1564']
    for col in numeric_cols:
        if col in villes_data.columns:
            villes_data[col] = pandas.to_numeric(villes_data[col], errors='coerce')

    # Regroupement des arrondissements de Paris et Marseille
    villes_data_copy = villes_data.copy()

    # Identifier les arrondissements de Paris et Marseille
    paris_mask = villes_data_copy['nom_commune_complet'].str.contains(r'Paris \d+', case=False, na=False)
    marseille_mask = villes_data_copy['nom_commune_complet'].str.contains(r'Marseille \d+', case=False, na=False)

    # Extraire les arrondissements
    paris_arrondissements = villes_data_copy[paris_mask]
    marseille_arrondissements = villes_data_copy[marseille_mask]

    # Supprimer les arrondissements individuels
    villes_data = villes_data_copy[~(paris_mask | marseille_mask)].copy()

    # Regrouper Paris si des arrondissements existent
    if not paris_arrondissements.empty:
        paris_groupe = {
            'nom_commune_complet': 'Paris',
            'P22_POP': paris_arrondissements['P22_POP'].sum(),
            'SUPERF': paris_arrondissements['SUPERF'].sum(),
            'MED21': paris_arrondissements['MED21'].mean(),
            'P22_EMPLT': paris_arrondissements['P22_EMPLT'].sum(),
            'P22_CHOM1564': paris_arrondissements['P22_CHOM1564'].sum(),
            'P22_ACT1564': paris_arrondissements['P22_ACT1564'].sum(),
            'latitude': paris_arrondissements['latitude'].mean(),
            'longitude': paris_arrondissements['longitude'].mean(),
            'nom_departement': 'Paris',
            'nom_region': paris_arrondissements['nom_region'].iloc[0] if 'nom_region' in paris_arrondissements.columns else 'Île-de-France'
        }
        villes_data = pandas.concat([villes_data, pandas.DataFrame([paris_groupe])], ignore_index=True)

    # Regrouper Marseille si des arrondissements existent
    if not marseille_arrondissements.empty:
        marseille_groupe = {
            'nom_commune_complet': 'Marseille',
            'P22_POP': marseille_arrondissements['P22_POP'].sum(),
            'SUPERF': marseille_arrondissements['SUPERF'].sum(),
            'MED21': marseille_arrondissements['MED21'].mean(),
            'P22_EMPLT': marseille_arrondissements['P22_EMPLT'].sum(),
            'P22_CHOM1564': marseille_arrondissements['P22_CHOM1564'].sum(),
            'P22_ACT1564': marseille_arrondissements['P22_ACT1564'].sum(),
            'latitude': marseille_arrondissements['latitude'].mean(),
            'longitude': marseille_arrondissements['longitude'].mean(),
            'nom_departement': 'Bouches-du-Rhône',
            'nom_region': marseille_arrondissements['nom_region'].iloc[0] if 'nom_region' in marseille_arrondissements.columns else 'Provence-Alpes-Côte d\'Azur'
        }
        villes_data = pandas.concat([villes_data, pandas.DataFrame([marseille_groupe])], ignore_index=True)

    streamlit.title("🗺️ Vue d'Ensemble - France")
    streamlit.markdown(f"**{len(villes_data)} villes** de plus de 20 000 habitants")

    # ═══════════════════════════════════════════════════════════════════════════════
    # STATISTIQUES NATIONALES
    # ═══════════════════════════════════════════════════════════════════════════════

    streamlit.header("📊 Statistiques Nationales", divider="blue")

    col1, col2, col3, col4 = streamlit.columns(4)

    with col1:
        total_pop = pandas.to_numeric(villes_data['P22_POP'], errors='coerce').sum()
        streamlit.metric("Population totale", fmt(int(total_pop)))

    with col2:
        pop_moyenne = pandas.to_numeric(villes_data['P22_POP'], errors='coerce').mean()
        streamlit.metric("Population moyenne", fmt(int(pop_moyenne)))

    with col3:
        total_emplois = pandas.to_numeric(villes_data['P22_EMPLT'], errors='coerce').sum()
        streamlit.metric("Emplois totaux", fmt(int(total_emplois)))

    with col4:
        revenu_median_national = pandas.to_numeric(villes_data['MED21'], errors='coerce').median()
        streamlit.metric("Revenu médian national", f"{fmt(int(revenu_median_national))} €")

    # ═══════════════════════════════════════════════════════════════════════════════
    # CARTE INTERACTIVE DE FRANCE
    # ═══════════════════════════════════════════════════════════════════════════════

    streamlit.header("🗺️ Carte Interactive des Villes", divider="blue")

    # Sélecteur de métrique à afficher
    metric_options = {
        "Population": "P22_POP",
        "Densité": "densite",
        "Revenu médian": "MED21",
        "Emplois": "P22_EMPLT",
        "Taux de chômage": "taux_chomage"
    }

    selected_metric = streamlit.selectbox(
        "Choisir la métrique à afficher sur la carte :",
        list(metric_options.keys()),
        index=0
    )

    # Calcul des métriques dérivées
    villes_map = villes_data.copy()
    villes_map['P22_POP'] = pandas.to_numeric(villes_map['P22_POP'], errors='coerce')
    villes_map['SUPERF'] = pandas.to_numeric(villes_map['SUPERF'], errors='coerce')
    villes_map['MED21'] = pandas.to_numeric(villes_map['MED21'], errors='coerce')
    villes_map['P22_EMPLT'] = pandas.to_numeric(villes_map['P22_EMPLT'], errors='coerce')
    villes_map['P22_CHOM1564'] = pandas.to_numeric(villes_map['P22_CHOM1564'], errors='coerce')
    villes_map['P22_ACT1564'] = pandas.to_numeric(villes_map['P22_ACT1564'], errors='coerce')

    villes_map['densite'] = villes_map['P22_POP'] / villes_map['SUPERF']
    villes_map['taux_chomage'] = (villes_map['P22_CHOM1564'] / villes_map['P22_ACT1564'] * 100).fillna(0)

    villes_map['pop_fmt'] = villes_map['P22_POP'].apply(lambda x: fmt(int(x)) if pandas.notna(x) else "N/A")
    villes_map['rev_fmt'] = villes_map['MED21'].apply(lambda x: f"{fmt(int(x))} €" if pandas.notna(x) else "N/A")
    villes_map['emploi_fmt'] = villes_map['P22_EMPLT'].apply(lambda x: fmt(int(x)) if pandas.notna(x) else "N/A")
    villes_map['densite_fmt'] = villes_map['densite'].apply(lambda x: fmt(int(x)) if pandas.notna(x) else "N/A")
    villes_map['chomage_fmt'] = villes_map['taux_chomage'].apply(lambda x: f"{x:.1f} %" if pandas.notna(x) else "N/A")

    metric_col = metric_options[selected_metric]

    metric_fmt_map = {
        "Population": 'pop_fmt',
        "Densité": 'densite_fmt',
        "Revenu médian": 'rev_fmt',
        "Emplois": 'emploi_fmt',
        "Taux de chômage": 'chomage_fmt'
    }
    villes_map['metric_fmt'] = villes_map[metric_fmt_map[selected_metric]]

    # Création de la carte
    fig_map = px.scatter_mapbox(
        villes_map,
        lat="latitude",
        lon="longitude",
        size="P22_POP",
        color=metric_col,
        hover_name="nom_commune_complet",
        custom_data=['nom_departement', 'pop_fmt', 'rev_fmt', 'emploi_fmt', 'densite_fmt', 'chomage_fmt', 'metric_fmt'],
        color_continuous_scale="Viridis",
        zoom=5,
        height=600,
        mapbox_style="carto-positron",
        title=f"Répartition des villes par {selected_metric}"
    )

    fig_map.update_traces(
        hovertemplate=(
            "<b>%{hovertext}</b><br>"
            "Département : %{customdata[0]}<br>"
            "Population : %{customdata[1]} hab<br>"
            "Revenu médian : %{customdata[2]}<br>"
            "Emplois : %{customdata[3]}<br>"
            "Densité : %{customdata[4]} hab/km²<br>"
            "Taux de chômage : %{customdata[5]}<br>"
            f"<b>{selected_metric} : %{{customdata[6]}}</b>"
            "<extra></extra>"
        ),
        hoverlabel=dict(
            bgcolor="rgba(255,255,255,0.96)",
            bordercolor="#22c55e",
            font=dict(color="#0f172a", size=13)
        )
    )

    fig_map.update_layout(
        margin={"r": 0, "t": 40, "l": 0, "b": 0},
        font=dict(family='Inter, sans-serif'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
    )

    streamlit.plotly_chart(fig_map, use_container_width=True)

    # ═══════════════════════════════════════════════════════════════════════════════
    # CLASSEMENTS - TOP 10
    # ═══════════════════════════════════════════════════════════════════════════════

    streamlit.header("🏆 Classements", divider="blue")

    col1, col2 = streamlit.columns(2)

    with col1:
        streamlit.subheader("🏙️ Top 10 - Population")
        top_pop = villes_data.nlargest(10, 'P22_POP')[['nom_commune_complet', 'P22_POP', 'nom_departement']]
        top_pop_display = top_pop.copy()
        top_pop_display['P22_POP'] = top_pop_display['P22_POP'].apply(lambda x: fmt(int(x)))
        top_pop_display.columns = ['Ville', 'Population', 'Département']
        streamlit.dataframe(top_pop_display, use_container_width=True, hide_index=True)

    with col2:
        streamlit.subheader("💰 Top 10 - Revenu Médian")
        top_revenu = villes_data.nlargest(10, 'MED21')[['nom_commune_complet', 'MED21', 'nom_departement']]
        top_revenu_display = top_revenu.copy()
        top_revenu_display['MED21'] = top_revenu_display['MED21'].apply(lambda x: f"{fmt(int(x))} €")
        top_revenu_display.columns = ['Ville', 'Revenu Médian', 'Département']
        streamlit.dataframe(top_revenu_display, use_container_width=True, hide_index=True)

    # ═══════════════════════════════════════════════════════════════════════════════
    # DISTRIBUTIONS STATISTIQUES
    # ═══════════════════════════════════════════════════════════════════════════════

    streamlit.header("📈 Distributions Statistiques", divider="blue")

    fig_dist = make_subplots(
        rows=2, cols=2,
        subplot_titles=(
            "Distribution de la Population",
            "Distribution du Revenu Médian",
            "Distribution du Taux de Chômage",
            "Distribution de la Densité"
        ),
        specs=[[{"type": "histogram"}, {"type": "histogram"}],
               [{"type": "histogram"}, {"type": "histogram"}]]
    )

    # Population
    fig_dist.add_trace(
        go.Histogram(x=villes_data['P22_POP'], nbinsx=50, marker_color=COULEUR_A, name='Population'),
        row=1, col=1
    )

    # Revenu médian
    fig_dist.add_trace(
        go.Histogram(x=villes_data['MED21'], nbinsx=50, marker_color=COULEUR_B, name='Revenu'),
        row=1, col=2
    )

    # Taux de chômage
    taux_chom = (villes_data['P22_CHOM1564'] / villes_data['P22_ACT1564'] * 100).dropna()
    fig_dist.add_trace(
        go.Histogram(x=taux_chom, nbinsx=50, marker_color='#10b981', name='Chômage'),
        row=2, col=1
    )

    # Densité
    densite = (villes_data['P22_POP'] / villes_data['SUPERF']).dropna()
    fig_dist.add_trace(
        go.Histogram(x=densite, nbinsx=50, marker_color='#f59e0b', name='Densité'),
        row=2, col=2
    )

    fig_dist.update_layout(
        height=600,
        showlegend=False,
        font=dict(family='Inter, sans-serif'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
    )

    fig_dist.update_xaxes(title_text="Habitants", row=1, col=1)
    fig_dist.update_xaxes(title_text="Euros (€)", row=1, col=2)
    fig_dist.update_xaxes(title_text="Taux (%)", row=2, col=1)
    fig_dist.update_xaxes(title_text="Hab/km²", row=2, col=2)

    streamlit.plotly_chart(fig_dist, use_container_width=True)

    # ═══════════════════════════════════════════════════════════════════════════════
    # ANALYSE PAR RÉGION
    # ═══════════════════════════════════════════════════════════════════════════════

    streamlit.header("🌍 Analyse par Région", divider="blue")

    if 'nom_region' in villes_data.columns:
        # Agrégation par région
        regions_stats = villes_data.groupby('nom_region').agg({
            'P22_POP': 'sum',
            'P22_EMPLT': 'sum',
            'MED21': 'mean',
            'nom_commune_complet': 'count'
        }).reset_index()

        regions_stats.columns = ['Région', 'Population', 'Emplois', 'Revenu Moyen', 'Nb Villes']
        regions_stats = regions_stats.sort_values('Population', ascending=False)

        # Graphique des régions
        fig_regions = go.Figure()

        fig_regions.add_trace(go.Bar(
            x=regions_stats['Région'],
            y=regions_stats['Population'],
            marker_color=COULEUR_A,
            name='Population',
            text=regions_stats['Population'].apply(lambda x: fmt(int(x))),
            textposition='outside'
        ))

        fig_regions.update_layout(
            title="Population par Région",
            xaxis_title="Région",
            yaxis_title="Population",
            height=500,
            font=dict(family='Inter, sans-serif'),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            xaxis={'categoryorder': 'total descending'}
        )

        streamlit.plotly_chart(fig_regions, use_container_width=True)

        # Tableau des régions
        streamlit.subheader("📋 Statistiques par Région")
        regions_display = regions_stats.copy()
        regions_display['Population'] = regions_display['Population'].apply(lambda x: fmt(int(x)) if pandas.notna(x) else "N/A")
        regions_display['Emplois'] = regions_display['Emplois'].apply(lambda x: fmt(int(x)) if pandas.notna(x) else "N/A")
        regions_display['Revenu Moyen'] = regions_display['Revenu Moyen'].apply(lambda x: f"{fmt(int(x))} €" if pandas.notna(x) else "N/A")

        streamlit.dataframe(regions_display, use_container_width=True, hide_index=True)

