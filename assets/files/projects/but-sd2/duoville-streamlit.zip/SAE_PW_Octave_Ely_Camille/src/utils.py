"""
Fonctions utilitaires partagées.
"""

import pandas


def fmt(val):
    """Formate un nombre avec des espaces."""
    return f"{int(val):,}".replace(",", " ")


def delta_str(val_a, val_b, suffix="", inverse=False):
    """Calcule le delta A vs B pour les metrics."""
    try:
        diff = float(val_a) - float(val_b)
    except (ValueError, TypeError):
        return None
    if inverse:
        diff = -diff
    if abs(diff) < 0.01:
        return None
    return f"{diff:+,.0f}{suffix}".replace(",", " ") if suffix != "%" else f"{diff:+.1f}{suffix}"


def normaliser(val, col_name, villes_data):
    """Normalise une valeur entre 0 et 100 par rapport au min/max de toutes les villes."""
    val = pandas.to_numeric(val, errors='coerce')
    if pandas.isna(val):
        return 50
    col_data = pandas.to_numeric(villes_data[col_name], errors='coerce').dropna()
    vmin, vmax = col_data.min(), col_data.max()
    if vmax == vmin:
        return 50
    return float((val - vmin) / (vmax - vmin) * 100)


def exploser_liste(df, col):
    """Explose une colonne contenant des listes et compte les valeurs."""
    if df.empty or col not in df.columns:
        return pandas.Series(dtype=int)
    series = df[col].dropna()
    toutes = []
    for val in series:
        if isinstance(val, list):
            toutes.extend([str(v).strip() for v in val])
        else:
            toutes.append(str(val).strip())
    counts = pandas.Series(toutes).value_counts()
    poubelle = {'nan', 'None', '', 'NaN', 'null', 'false', 'False', 'true', 'True'}
    return counts[~counts.index.isin(poubelle)]


def code_meteo_vers_emoji(code):
    """Code WMO -> emoji."""
    return {
        0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️",
        45: "🌫️", 48: "🌫️", 51: "🌦️", 53: "🌧️", 55: "🌧️",
        61: "🌧️", 63: "🌧️", 65: "🌧️", 71: "🌨️", 73: "🌨️", 75: "🌨️",
        80: "🌦️", 81: "🌧️", 82: "⛈️", 95: "⛈️", 96: "⛈️", 99: "⛈️"
    }.get(code, "🌡️")
