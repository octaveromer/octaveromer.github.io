"""
Configuration et constantes de l'application.
"""

import os

COULEUR_A = '#6366f1'   # Indigo
COULEUR_B = '#f97316'   # Orange

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')

SECTEURS_LABELS = {
    'ETAZ23': 'Agriculture',
    'ETBE23': 'Industrie',
    'ETFZ23': 'Construction',
    'ETGU23': 'Commerce & Services',
    'ETOQ23': 'Administration',
}

LABELS_TOURISME = {
    'hotel': 'Hôtel', 'motel': 'Motel', 'hostel': 'Auberge',
    'guest_house': "Maison d'hôtes", 'apartment': 'Appartement',
    'attraction': 'Attraction', 'museum': 'Musée',
    'gallery': 'Galerie', 'artwork': "Œuvre d'art",
    'viewpoint': 'Point de vue', 'information': 'Office tourisme',
    'camp_site': 'Camping', 'caravan_site': 'Aire camping-car',
    'picnic_site': 'Aire pique-nique', 'theme_park': 'Parc à thème',
}

CSS_STYLE = """<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');

    /* ========== BACKGROUND & LAYOUT ========== */
    .stApp {
        background: linear-gradient(160deg, #f8fafc 0%, #eef2ff 50%, #f5f3ff 100%);
    }

    /* ========== SIDEBAR ========== */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1e1b4b 0%, #312e81 100%) !important;
        box-shadow: 4px 0 20px rgba(0,0,0,0.1);
    }
    section[data-testid="stSidebar"] h1,
    section[data-testid="stSidebar"] h2,
    section[data-testid="stSidebar"] h3,
    section[data-testid="stSidebar"] p,
    section[data-testid="stSidebar"] span,
    section[data-testid="stSidebar"] label,
    section[data-testid="stSidebar"] .stMarkdown {
        color: rgba(255,255,255,0.95) !important;
    }
    section[data-testid="stSidebar"] hr {
        border-color: rgba(255,255,255,0.15) !important;
        margin: 1.5rem 0;
    }
    section[data-testid="stSidebar"] .stAlert {
        background: rgba(255,255,255,0.1) !important;
        border-color: rgba(255,255,255,0.2) !important;
        border-radius: 12px;
    }

    /* ========== METRICS CARDS ========== */
    [data-testid="stMetric"] {
        background: linear-gradient(135deg, #ffffff 0%, #f9fafb 100%);
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.25rem 1.5rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    [data-testid="stMetric"]:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 32px rgba(99, 102, 241, 0.15), 0 2px 8px rgba(0,0,0,0.08);
        border-color: #c7d2fe;
    }
    [data-testid="stMetricValue"] {
        font-weight: 800 !important;
        font-size: 1.75rem !important;
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    [data-testid="stMetricLabel"] {
        font-weight: 500 !important;
        color: #64748b !important;
        text-transform: uppercase;
        font-size: 0.75rem !important;
        letter-spacing: 0.5px;
    }

    /* ========== TABS ========== */
    .stTabs [data-baseweb="tab-list"] {
        gap: 4px;
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
        border-radius: 16px;
        padding: 6px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 12px;
        font-weight: 600;
        padding: 0.75rem 1.5rem;
        transition: all 0.3s;
    }
    .stTabs [data-baseweb="tab"]:hover {
        background: rgba(99, 102, 241, 0.08);
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
    }
    .stTabs [aria-selected="true"] p {
        color: white !important;
        font-weight: 700 !important;
    }

    /* ========== CHARTS & GRAPHS ========== */
    [data-testid="stPlotlyChart"] {
        background: white;
        border-radius: 16px;
        padding: 1rem;
        border: 1px solid #e2e8f0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        transition: box-shadow 0.3s;
    }
    [data-testid="stPlotlyChart"]:hover {
        box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    }

    /* ========== HEADERS ========== */
    h1 {
        letter-spacing: -1.5px !important;
        font-weight: 900 !important;
        color: #1e1b4b !important;
        font-size: 3rem !important;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin-bottom: 1rem !important;
    }
    h2 {
        letter-spacing: -0.8px !important;
        font-weight: 700 !important;
        color: #312e81 !important;
        font-size: 1.75rem !important;
        margin-top: 2rem !important;
    }
    h3 {
        font-weight: 600 !important;
        color: #4f46e5 !important;
        font-size: 1.25rem !important;
    }

    /* ========== BUTTONS & INPUTS ========== */
    .stButton > button {
        border-radius: 12px;
        font-weight: 600;
        padding: 0.75rem 2rem;
        transition: all 0.3s;
        border: none;
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: white;
    }
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
    }

    .stTextInput > div > div > input,
    .stSelectbox > div > div > select {
        border-radius: 12px;
        border: 2px solid #e2e8f0;
        padding: 0.75rem 1rem;
        transition: border-color 0.3s;
    }
    .stTextInput > div > div > input:focus,
    .stSelectbox > div > div > select:focus {
        border-color: #6366f1;
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    }

    /* ========== ALERTS & INFO ========== */
    .stAlert {
        border-radius: 14px !important;
        border-left: 4px solid !important;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    /* ========== EXPANDER ========== */
    .streamlit-expanderHeader {
        border-radius: 12px !important;
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
        border: 1px solid #e2e8f0;
        font-weight: 600;
        padding: 1rem 1.5rem;
        transition: all 0.3s;
    }
    .streamlit-expanderHeader:hover {
        background: linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
        border-color: #c7d2fe;
    }

    /* ========== DATAFRAMES ========== */
    .stDataFrame {
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    /* ========== RADIO BUTTONS ========== */
    .stRadio > div {
        background: white;
        padding: 0.5rem;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
    }
    section[data-testid="stSidebar"] .stRadio label,
    section[data-testid="stSidebar"] .stRadio p,
    section[data-testid="stSidebar"] .stRadio span {
        color: #1e293b !important;
    }

    /* ========== DIVIDERS ========== */
    hr {
        margin: 2rem 0;
        border: none;
        height: 2px;
        background: linear-gradient(90deg, transparent, #6366f1, transparent);
        opacity: 0.3;
    }

    /* ========== MARKDOWN & TEXT ========== */
    .stMarkdown p {
        font-size: 1.05rem;
        line-height: 1.7;
        color: #475569;
    }
    .stMarkdown strong {
        color: #1e293b;
        font-weight: 700;
    }
    .stMarkdown em {
        color: #64748b;
        font-style: italic;
    }

    /* ========== CAPTIONS ========== */
    .stCaptionContainer {
        color: #94a3b8 !important;
        font-size: 0.9rem;
    }

    /* ========== SCROLLBARS ========== */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    ::-webkit-scrollbar-track {
        background: #f1f5f9;
        border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #4f46e5, #7c3aed);
    }
</style>"""
