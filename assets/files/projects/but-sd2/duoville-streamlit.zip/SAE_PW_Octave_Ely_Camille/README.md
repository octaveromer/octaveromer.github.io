# Comparateur de Villes Françaises

**Projet BUT SD2 VCOD - Programmation Web**  
**Auteurs :** Octave, Ely, Camille  
**Date :** Mars 2026

---

## 🚀 Lancer l'application

Double-cliquez sur **`lancer_projet.bat`**.

Le script installe automatiquement les dépendances et lance l'application dans votre navigateur.

> **Si Python n'est pas installé**, téléchargez-le sur https://www.python.org/downloads/ et cochez **"Add Python to PATH"** lors de l'installation.

---

## 📋 Fonctionnalités

L'application compare deux villes françaises de plus de 20 000 habitants (par défaut **Niort** et **Bordeaux**) à travers 8 onglets :

- 📍 **Généralités** : population, superficie, densité, nombre de ménages, revenu médian et carte interactive
- 💼 **Emploi** : taux d'activité, taux de chômage, répartition des emplois salariés / non-salariés
- 🏠 **Logement** : types de logements, taux de vacance, proportion propriétaires / locataires
- 🌦️ **Météo** : prévisions sur 5 jours en temps réel (API Open-Meteo)
- 🎓 **Formation** : offre de formation Parcoursup (filières, capacités, sélectivité, statut public/privé)
- 🏅 **Sports** : équipements sportifs recensés par type (data.sports.gouv.fr)
- 🧭 **Tourisme** : sites touristiques dans un rayon de 10 km (OpenStreetMap)
- 🏆 **Classement** : position de chaque ville parmi toutes les villes de + de 20 000 habitants

---

## 🏗️ Architecture du Projet

Le projet suit une architecture modulaire et professionnelle :

```
SAE_Web_Octave_Ely_Camille-main/
├── main.py                    # Point d'entrée principal
├── lancer_projet.bat          # Script de lancement Windows
├── index.html                 # Page d'accueil HTML
├── requirements.txt           # Dépendances Python
│
├── data/                      # Données CSV
│   ├── base_cc_comparateur.csv
│   ├── base_formation_parcoursup.csv
│   └── 20230823-communes-departement-region.csv
│
└── src/                       # Code source modulaire
    ├── config.py              # Configuration et constantes
    ├── data_loader.py         # Chargement des données
    ├── api.py                 # Appels aux APIs externes
    ├── utils.py               # Fonctions utilitaires
    ├── charts.py              # Mise en forme des graphiques
    │
    └── tabs/                  # Modules des onglets
        ├── generalites.py     # Onglet Généralités
        ├── emploi.py          # Onglet Emploi
        ├── logement.py        # Onglet Logement
        ├── meteo.py           # Onglet Météo
        ├── formation.py       # Onglet Formation
        ├── sports.py          # Onglet Sports
        ├── tourisme.py        # Onglet Tourisme
        └── classement.py      # Onglet Classement
```

---

## 🛠️ Technologies Utilisées

- **Python 3.9+**
- **Streamlit** : Framework d'interface utilisateur
- **Pandas** : Manipulation de données
- **Plotly** : Visualisations interactives
- **Requests** : Appels aux APIs externes

**APIs externes :**
- Open-Meteo (prévisions météo)
- data.sports.gouv.fr (équipements sportifs)
- Overpass API / OpenStreetMap (sites touristiques)

---

## 👥 Auteurs

Projet BUT SD2 VCOD - Mars 2026
