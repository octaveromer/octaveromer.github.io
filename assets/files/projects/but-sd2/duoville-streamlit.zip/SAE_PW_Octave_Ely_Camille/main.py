"""
Application Streamlit - Comparateur de Villes Françaises
Projet noté BUT SD2 VCOD - Programmation Web

Auteurs: Octave, Ely, Camille
Date: Mars 2026
"""

import streamlit

from src.config import CSS_STYLE
from src.data_loader import charger_donnees, charger_formations
from src.tabs import generalites, emploi, logement, meteo, formation, sports, tourisme, classement
from src import dashboard_france

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

streamlit.set_page_config(
    page_title="Comparateur de Villes Françaises",
    page_icon="🏙️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Appliquer le CSS personnalisé
streamlit.markdown(CSS_STYLE, unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════════════════════
# CHARGEMENT DES DONNÉES
# ═══════════════════════════════════════════════════════════════════════════════

villes_data = charger_donnees()
formations_data = charger_formations()
liste_villes = list(villes_data["nom_commune_complet"])

# Cross-filtering : appliquer le clic sur barre AVANT la création du widget radio
if '_pending_mise_en_avant' in streamlit.session_state:
    streamlit.session_state['mise_en_avant'] = streamlit.session_state.pop('_pending_mise_en_avant')

# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR - NAVIGATION
# ═══════════════════════════════════════════════════════════════════════════════

with streamlit.sidebar:
    streamlit.title("DuoVille")

    # Navigation principale
    mode = streamlit.radio(
        "Mode d'affichage",
        ["🔄 Comparer 2 Villes", "🗺️ Vue d'Ensemble France"],
        key="mode_affichage",
        label_visibility="collapsed"
    )

    streamlit.markdown("---")

    # Si mode comparaison, afficher les sélecteurs
    if mode == "🔄 Comparer 2 Villes":
        streamlit.subheader("Sélection des villes")

        default_A = liste_villes.index("Niort") if "Niort" in liste_villes else 0
        default_B = liste_villes.index("Bordeaux") if "Bordeaux" in liste_villes else min(1, len(liste_villes) - 1)

        ville_A = streamlit.selectbox("🔵 Ville A", liste_villes, index=default_A, key="ville_a")
        ville_B = streamlit.selectbox("🟠 Ville B", liste_villes, index=default_B, key="ville_b")

        streamlit.markdown("---")
        streamlit.subheader("🎯 Mise en avant")
        mise_en_avant = streamlit.radio(
            "Isoler une ville sur tous les graphiques :",
            ["Les deux", ville_A, ville_B],
            key="mise_en_avant",
            horizontal=True
        )

    streamlit.markdown("---")
    streamlit.info(f"📊 **{len(liste_villes)}** villes disponibles\n(> 20 000 habitants)")
    streamlit.caption("Projet BUT SD2 VCOD — Mars 2026")

# ═══════════════════════════════════════════════════════════════════════════════
# AFFICHAGE SELON LE MODE
# ═══════════════════════════════════════════════════════════════════════════════

if mode == "🗺️ Vue d'Ensemble France":
    # ─── MODE VUE FRANCE ───
    dashboard_france.afficher(villes_data)

else:
    # ─── MODE COMPARAISON 2 VILLES ───

    # Récupération des données des villes sélectionnées
    temp_A = villes_data.query("nom_commune_complet == @ville_A")
    temp_B = villes_data.query("nom_commune_complet == @ville_B")

    # Calcul de l'opacité selon la mise en avant
    opacity_A = 1.0 if mise_en_avant in ["Les deux", ville_A] else 0.15
    opacity_B = 1.0 if mise_en_avant in ["Les deux", ville_B] else 0.15

    # Extraction des coordonnées GPS
    lat_A, lon_A = temp_A['latitude'].values[0], temp_A['longitude'].values[0]
    lat_B, lon_B = temp_B['latitude'].values[0], temp_B['longitude'].values[0]

    # ─── EN-TÊTE ───
    streamlit.title(f"🔄 Comparaison : {ville_A} vs {ville_B}")
    streamlit.markdown(f"*Comparez deux villes françaises sur 8 dimensions*")
    streamlit.markdown("---")

    # ─── ONGLETS DE COMPARAISON ───
    onglet1, onglet2, onglet3, onglet4, onglet5, onglet6, onglet7, onglet8 = streamlit.tabs([
        "📍 Généralités", "💼 Emploi", "🏠 Logement", "🌦️ Météo",
        "🎓 Formation", "🏅 Sports", "🧭 Tourisme", "🏆 Classement"
    ])

    with onglet1:
        generalites.afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B, villes_data)

    with onglet2:
        emploi.afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B)

    with onglet3:
        logement.afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B)

    with onglet4:
        meteo.afficher(ville_A, ville_B, lat_A, lon_A, lat_B, lon_B)

    with onglet5:
        formation.afficher(ville_A, ville_B, opacity_A, opacity_B, formations_data)

    with onglet6:
        sports.afficher(ville_A, ville_B, opacity_A, opacity_B)

    with onglet7:
        tourisme.afficher(ville_A, ville_B, lat_A, lon_A, lat_B, lon_B, opacity_A, opacity_B)

    with onglet8:
        classement.afficher(ville_A, ville_B, temp_A, temp_B, opacity_A, opacity_B, villes_data)
